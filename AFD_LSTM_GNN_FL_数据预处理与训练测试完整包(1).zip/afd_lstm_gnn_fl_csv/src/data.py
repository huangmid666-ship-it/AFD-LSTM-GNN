"""实际八份 CSV 的适配、可用时点对齐、冻结变换、原生标签与图构造。"""
from dataclasses import dataclass, field
from pathlib import Path
import json
import math
import re
import numpy as np
import pandas as pd
from .afd import decompose

VARIABLES = {
    "B": ["target_level", "log_tests", "age_mean", "female_fraction"],
    "C": ["temp_mean", "temp_max", "temp_min", "precip_sum", "rh_mean",
          "wind_mean", "pressure_mean", "radiation_mean"],
    "E": ["pm25", "pm10", "o3", "no2", "so2", "co"],
    "V": ["log_inbound_daily_background"],
}
COUNTRIES = ["China", "Portugal", "Brazil"]
COUNTRY_NAMES = {"中国": "China", "葡萄牙": "Portugal", "巴西": "Brazil",
                 "CN": "China", "PT": "Portugal", "BR": "Brazil"}
PATHOGENS = {"甲型流感病毒": "influenza_a", "流感A": "influenza_a",
             "乙型流感病毒": "influenza_b", "流感B": "influenza_b",
             "新型冠状病毒": "sars_cov_2", "新冠": "sars_cov_2",
             "SARS-CoV-2": "sars_cov_2", "流感": "influenza", "Influenza": "influenza"}
STATIC_FIELDS = ["latitude", "longitude", "population", "density", "elevation",
                 "area", "is_China", "is_Portugal", "is_Brazil"]
FREQUENCIES = {"daily": (1, 0), "weekly": (7, 1), "monthly": (30, 2), "other": (365, 3)}


def country_name(value):
    return COUNTRY_NAMES.get(str(value), str(value)) if pd.notna(value) else None


def age_in_years(value):
    if pd.isna(value):
        return np.nan
    text = str(value).strip()
    if re.fullmatch(r"\d+(?:\.\d+)?", text):
        return float(text)
    parts = re.findall(r"(\d+(?:\.\d+)?)\s*(岁|年|个月|月|天|日)", text)
    if not parts:
        return np.nan
    scale = {"岁": 1., "年": 1., "个月": 1/12., "月": 1/12., "天": 1/365.2425, "日": 1/365.2425}
    return sum(float(n)*scale[unit] for n, unit in parts)


def dump_json(path, payload):
    Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2,
                                    default=str, allow_nan=False), encoding="utf-8")


@dataclass
class Record:
    start: pd.Timestamp
    end: pd.Timestamp
    available: pd.Timestamp
    value: float
    record_id: str
    frequency: str = "daily"
    quality: float = 1.0


@dataclass
class Task:
    task_id: str
    client: str
    pathogen: str
    kind: str
    country: str | None
    frequency: str
    labels: pd.DataFrame  # start,end,available,Y,n,quality,label_id
    history: dict
    description: str
    admin1: str | None = None
    air_city: str | None = None
    target_mean: float = 0.0
    target_std: float = 1.0


class FrozenScaler:
    """只以训练截止日前已可用的原生记录拟合；占位不参加拟合。"""
    def __init__(self, mean=0., std=1., count=0):
        self.mean, self.std, self.count = float(mean), float(std), int(count)

    @classmethod
    def fit(cls, records, cutoff):
        x = [r.value for r in records if r.end <= cutoff and r.available <= cutoff
             and np.isfinite(r.value)]
        return cls(np.mean(x), max(float(np.std(x)), 1e-6), len(x)) if x else cls()

    def as_dict(self):
        return {"mean": self.mean, "std": self.std, "native_records": self.count}


def align_records(records, calendar, scaler, structural=True, stop_periods=7, decay=.2,
                  period_days=None):
    """因果版：每个历史日只读取该日可见版本，不向前回写右端点。

    13 通道：值、原生观测、结构可用、陈旧度、可靠性、4状态、4频率。
    returns values [T,13], native support record ids [T]。
    正常周/月沿用不被记为多个原生观测；超期参考占位可靠性严格为 0。
    """
    calendar = pd.DatetimeIndex(calendar)
    out = np.zeros((len(calendar), 13), dtype=np.float32)
    ids = [None]*len(calendar)
    out[:, 2] = float(structural)
    out[:, 8] = 1  # reference 状态
    ordered = sorted([r for r in records if np.isfinite(r.value)],
                     key=lambda r: (r.available, r.end, r.record_id))
    pointer, known = 0, {}  # 同一原生记录的不同发布版本可更新，旧区间不倒退最新区间
    for i, day in enumerate(calendar):
        while pointer < len(ordered) and ordered[pointer].available <= day:
            r = ordered[pointer]
            if r.end <= day:
                previous = known.get(r.record_id)
                if previous is None or r.available >= previous.available:
                    known[r.record_id] = r
            pointer += 1
        if not structural or not known:
            continue
        r = max(known.values(), key=lambda x: (x.end, x.available))
        period, frequency_index = FREQUENCIES.get(r.frequency, FREQUENCIES["other"])
        if period_days is not None:
            period = period_days
        age = max(0, (day-r.end).days)
        out[i, 3] = min(age/period, 100.)
        out[i, 9:13] = 0
        out[i, 9+frequency_index] = 1
        if age > stop_periods*period:
            continue
        standardized = (r.value-scaler.mean)/scaler.std
        excess = max(0., age/period-1.)
        gamma = math.exp(-decay*excess)
        out[i, 0] = np.clip(standardized*gamma, -20, 20)
        out[i, 1] = float(r.end == day)
        out[i, 4] = r.quality*gamma
        out[i, 5:9] = 0
        # 原生观测标记按事件日期；状态区分今天新获实测值与继续沿用旧报告。
        out[i, 5 if r.available == day else 6] = 1
        ids[i] = r.record_id
    return out, ids


def causal_interpolate(values, observed_dates, available_dates, target_date, cutoff,
                       max_gap_days=3):
    """供另行选择的起点重建模式调用；默认主流程不用插值，不回写历史日。
    没有同时可见的左右端点即返回 None。
    """
    candidates = [(pd.Timestamp(d), float(x)) for x, d, a in
                  zip(values, observed_dates, available_dates)
                  if pd.Timestamp(a) <= pd.Timestamp(cutoff) and np.isfinite(x)]
    left = [(d, x) for d, x in candidates if d <= pd.Timestamp(target_date)]
    right = [(d, x) for d, x in candidates if d >= pd.Timestamp(target_date)]
    if not left or not right:
        return None
    d0, x0 = max(left); d1, x1 = min(right)
    if (d1-d0).days > max_gap_days:
        return None
    if d0 == d1:
        return x0
    ratio = (pd.Timestamp(target_date)-d0)/(d1-d0)
    return x0+float(ratio)*(x1-x0)


def calendar_features(dates):
    dates = pd.DatetimeIndex(dates)
    annual = 2*np.pi*(dates.dayofyear.to_numpy()-1)/365.2425
    weekly = 2*np.pi*dates.dayofweek.to_numpy()/7
    return np.column_stack([np.sin(annual), np.cos(annual),
                            np.sin(weekly), np.cos(weekly)]).astype(np.float32)


def maximum_run(mask):
    longest = current = 0
    for flag in mask:
        current = current+1 if flag else 0
        longest = max(current, longest)
    return longest


def static_features(country, optional_row=None, as_of=None):
    values, observed = np.zeros(9), np.zeros(9)
    optional_row = optional_row or {}
    release = pd.to_datetime(optional_row.get("available_at"), errors="coerce")
    physical_available = (pd.notna(release) and as_of is not None and
                          release <= pd.Timestamp(as_of))
    for i, name in enumerate(STATIC_FIELDS[:6]):
        value = optional_row.get(name, np.nan)
        if pd.notna(value) and physical_available:
            # 统一公共参考缩放，不跨客户端平均本地标准化统计量。
            scales = [90, 180, 1e8, 1e4, 5e3, 1e6]
            values[i] = float(value)/scales[i]; observed[i] = 1
    if country in COUNTRIES:
        observed[6:] = 1
        values[6+COUNTRIES.index(country)] = 1
    return np.column_stack([values, observed]).ravel().astype(np.float32)


class DataBuilder:
    def __init__(self, project_dir, config, frozen_scalers=None, frozen_targets=None):
        self.root = Path(project_dir)
        self.raw = self.root/"data/raw"
        self.optional = self.root/"data/optional"
        self.config = config
        self.audit = {"mode": config["mode"], "warnings": [], "files": [],
                      "rejected": [], "tasks": [], "release_delay_assumptions":
                      config["assumed_release_delay_days"]}
        self.frames = {}
        self.tasks = []
        self.scalers = {}
        self.geo_rows = {}
        self.public = {}
        self.edges = []
        self.forecasts = pd.DataFrame()
        self.frozen_scalers = frozen_scalers
        self.frozen_targets = frozen_targets or {}

    def warn(self, message):
        if message not in self.audit["warnings"]:
            self.audit["warnings"].append(message)

    def reject(self, source, reason, rows):
        self.audit["rejected"].append({"source": source, "reason": reason, "rows": int(rows)})

    def read(self, stem):
        paths = sorted(self.raw.glob(stem+"*.csv"))
        if not paths:
            self.warn(f"{stem}.csv 缺失：保留对应模态槽位并关闭信息贡献。")
            return pd.DataFrame()
        p = next((x for x in paths if x.name == stem+".csv"), paths[0])
        d = pd.read_csv(p, encoding="utf-8-sig", low_memory=False)
        self.audit["files"].append({"name": p.name, "rows": len(d), "columns": list(d)})
        return d

    def records(self, frame, variable, delay, frequency="daily", quality=1., prefix=""):
        out = []
        for row in frame.itertuples(index=False):
            value = getattr(row, variable, np.nan)
            if not pd.notna(value):
                continue
            end = pd.Timestamp(row.end).normalize()
            start = pd.Timestamp(getattr(row, "start", end)).normalize()
            actual_release = getattr(row, "available", pd.NaT)
            release = pd.Timestamp(actual_release).normalize() if pd.notna(actual_release) else end+pd.Timedelta(days=delay)
            if release < end:
                self.reject(prefix, "发布日期早于区间结束，记录排除", 1)
                continue
            coverage = getattr(row, variable+"_coverage", 1.)
            out.append(Record(start, end, release, float(value),
                              f"{prefix}:{variable}:{end.date()}", frequency, quality*float(coverage)))
        return out

    def _unique_domain(self, frame, keys, values, source):
        """同一原生空间时间键的冲突不能被平均成真值。"""
        if frame.empty:
            return frame
        d = frame.drop_duplicates(keys+values).copy()
        bad = d.duplicated(keys, keep=False)
        if bad.any():
            self.reject(source, "同一原生键存在冲突版本且无发布日志", bad.sum())
        return d[~bad]

    def build_sources(self):
        for stem in ["ydyl_clinical_domestic", "ydyl_pathogen_overseas",
                     "ydyl_meteorology_domestic", "ydyl_meteorology_overseas",
                     "ydyl_air_quality_domestic", "ydyl_air_quality_overseas",
                     "ydyl_aviation_domestic", "ydyl_aviation_overseas"]:
            self.frames[stem] = self.read(stem)
        self.warn("多数原始文件无独立发布日期；当前运行是假定发布延迟下的工程回测，不是已还原的实时预测。")
        self.warn("附件无单位清单。strict_unknown_units=false 时按文件数值作工程试跑；正式验证前需核对单位及 ERA5 历史可用版本。")
        if self.config["mode"] != "engineering_backtest":
            raise ValueError("当前附件缺发布日志，仅支持 engineering_backtest；不能通过配置把假定延迟回测改称正式实时预测。")
        units_path = self.optional/"verified_units.json"
        verified_units = json.loads(units_path.read_text(encoding="utf-8")) if units_path.exists() else {}
        for group, prefix, region_col in [("C", "ydyl_meteorology", "admin1_name"),
                                           ("E", "ydyl_air_quality", "city")]:
            available = [self.frames[prefix+"_"+domain] for domain in ["domestic", "overseas"]
                         if not self.frames[prefix+"_"+domain].empty]
            if not available:
                continue
            d = pd.concat(available, ignore_index=True)
            country_col = "country_name" if group == "C" else "country"
            d["country"] = d[country_col].map(country_name)
            d["end"] = pd.to_datetime(d.obs_date, errors="coerce").dt.normalize()
            d = d.dropna(subset=["country", "end", region_col])
            for variable in VARIABLES[group]:
                d[variable] = pd.to_numeric(d[variable], errors="coerce")
                if self.config["strict_unknown_units"] and not verified_units.get(variable):
                    d[variable] = np.nan
                    self.warn(f"{variable} 未核验单位，严格模式将其关闭。")
            d = self._unique_domain(d, ["country", region_col, "end"], VARIABLES[group], prefix)
            self.frames[group+"_locations"] = d
            permit = (self.config["allow_country_weather_background"] if group == "C"
                      else self.config["allow_country_station_proxy"])
            if not permit:
                if group == "E":
                    self.warn("无经核验站点—行政区映射，默认关闭国家污染代理；污染编码器及其槽位仍完整保留。")
                continue
            # 等权的省级背景/站点面板代理，不解释为面积/人口加权暴露。
            for country, subset in d.groupby("country"):
                panel = subset.groupby("end", as_index=False)[VARIABLES[group]].mean()
                counts = subset.groupby("end")[VARIABLES[group]].count()
                expected_locations = max(subset[region_col].nunique(), 1)
                for var in VARIABLES[group]:
                    panel[var+"_coverage"] = panel.end.map(counts[var]/expected_locations)
                    self.public[(country, group, var)] = self.records(
                        panel, var, self.config["assumed_release_delay_days"]["meteorology" if group == "C" else "air_quality"],
                        quality=.5, prefix=country+"_background")
                self.warn(f"{country} {group} 使用现有空间单元等权背景，空间可靠性设为0.5，并非全国暴露真值。")
        flights = [self.frames[x] for x in ["ydyl_aviation_domestic", "ydyl_aviation_overseas"]
                   if not self.frames[x].empty]
        if flights:
            d = pd.concat(flights, ignore_index=True)
            d["source"] = d.dep_country_name.map(country_name)
            d["target"] = d.arr_country_name.map(country_name)
            month = pd.to_datetime(d.month_id.astype(str), format="%Y%m", errors="coerce")
            d["start"] = month
            d["end"] = month+pd.offsets.MonthEnd(0)
            d["passenger_count"] = pd.to_numeric(d.passenger_count, errors="coerce")
            valid = d.end.notna() & d.passenger_count.ge(0)
            self.reject("aviation", "无效月份或负旅客量", (~valid).sum())
            d = self._unique_domain(d[valid], ["source", "target", "end"], ["passenger_count"], "aviation")
            delay = self.config["assumed_release_delay_days"]["aviation"]
            for row in d.itertuples():
                if row.source in COUNTRIES and row.target in COUNTRIES and row.source != row.target:
                    self.edges.append((row.source, row.target, Record(row.start, row.end,
                        row.end+pd.Timedelta(days=delay), row.passenger_count,
                        f"air:{row.source}:{row.target}:{row.end.date()}", "monthly")))
            for country, sub in d.groupby("target"):
                panel = sub.groupby(["start", "end"], as_index=False).passenger_count.sum()
                panel["log_inbound_daily_background"] = np.log1p(panel.passenger_count/panel.end.dt.days_in_month)
                self.public[(country, "V", VARIABLES["V"][0])] = self.records(
                    panel, VARIABLES["V"][0], delay, "monthly", prefix=country+"_inbound")
            self.warn("航空总量表示已记录航线面板的入境月均背景；未记录航线不补零，图仅保留当前节点间的已知有向边。")
        geo_path = self.optional/"geography.csv"
        if geo_path.exists():
            geo = pd.read_csv(geo_path)
            required = {"region_id", "country", "level", "available_at"}
            if not required <= set(geo):
                raise ValueError("geography.csv 缺少 region_id/country/level/available_at。")
            if geo.region_id.duplicated().any():
                raise ValueError("geography.csv 同一region_id存在多个版本；当前可选接口要求单一可用版本，不能覆盖其历史发布时间。")
            for row in geo.to_dict("records"):
                self.geo_rows[str(row["region_id"])] = row
                region_id, country = str(row["region_id"]), country_name(row["country"])
                if region_id in COUNTRIES:
                    continue
                for group, column in [("C", "admin1_name"), ("E", "city")]:
                    locations = self.frames.get(group+"_locations", pd.DataFrame())
                    if locations.empty:
                        continue
                    subset = locations[(locations.country == country) & (locations[column] == region_id)]
                    for var in VARIABLES[group]:
                        self.public[(region_id, group, var)] = self.records(subset, var,
                            self.config["assumed_release_delay_days"]["meteorology" if group == "C" else "air_quality"],
                            prefix=region_id+"_public")
        forecast_path = self.optional/"forecast_records.csv"
        if forecast_path.exists():
            self.forecasts = pd.read_csv(forecast_path)
            if not {"country", "issued_at", "target_date", "variable", "value"} <= set(self.forecasts):
                raise ValueError("未来预报必须保留 country/issued_at/target_date/variable/value。")
            self.forecasts["country"] = self.forecasts.country.map(country_name)
            for col in ["issued_at", "target_date"]:
                self.forecasts[col] = pd.to_datetime(self.forecasts[col], errors="raise").dt.normalize()
        self.build_clinical()
        self.build_overseas()
        self.build_smooth()
        if not self.tasks:
            raise ValueError("未找到语义明确的真实监督任务。请检查数据与配置。")
        for t in self.tasks:
            self.audit["tasks"].append({"task_id": t.task_id, "client": t.client,
                "pathogen": t.pathogen, "kind": t.kind, "country": t.country,
                "native_labels": len(t.labels), "description": t.description})

    def build_clinical(self):
        raw = self.frames["ydyl_clinical_domestic"]
        if raw.empty:
            return
        d = raw.copy()
        d["end"] = pd.to_datetime(d.date, errors="coerce").dt.normalize()
        d["age_num"] = d.age.map(age_in_years)
        d["female_num"] = d.sex.map({"女": 1., "男": 0.})
        self.reject("clinical", "无效日期", d.end.isna().sum())
        d = d.dropna(subset=["end"])
        country = country_name(self.config.get("clinical_country"))
        if country is None:
            self.warn("国内临床缺少来源地区，默认独立机构序列，不匹配任何国家/省市外部因素。")
        elif not self.config.get("clinical_admin1"):
            self.warn("仅配置临床所属国家，外部因素只作国家背景；不能解释为当地天气或污染暴露。")
        for pathogen in self.config["clinical_pathogens"]:
            if pathogen not in d:
                self.warn(f"临床无 {pathogen} 字段，该任务不建立。")
                continue
            mapped = d[pathogen].astype("string").str.strip().map({"阳性": 1., "阴性": 0.})
            malformed = d[pathogen].notna() & mapped.isna()
            self.reject("clinical:"+pathogen, "非阳性/阴性字段不进入检测分母", malformed.sum())
            valid = d[mapped.notna()].copy()
            valid["positive"] = mapped[mapped.notna()]
            if valid.empty:
                continue
            panel = valid.groupby("end", as_index=False).agg(Y=("positive", "sum"),
                n=("positive", "size"), age_mean=("age_num", "mean"), female_fraction=("female_num", "mean"),
                age_valid=("age_num", "count"), sex_valid=("female_num", "count"))
            weekly = self.config.get("clinical_weekly_labels", False)
            if weekly:
                valid["end"] += pd.to_timedelta(6-valid.end.dt.dayofweek, unit="D")
                panel = valid.groupby("end", as_index=False).agg(Y=("positive", "sum"),
                    n=("positive", "size"), age_mean=("age_num", "mean"), female_fraction=("female_num", "mean"),
                    age_valid=("age_num", "count"), sex_valid=("female_num", "count"))
            panel["age_mean_coverage"] = panel.age_valid/panel.n
            panel["female_fraction_coverage"] = panel.sex_valid/panel.n
            panel["start"] = panel.end-pd.Timedelta(days=6 if weekly else 0)
            panel["available"] = panel.end+pd.Timedelta(days=self.config["assumed_release_delay_days"]["clinical"])
            probability = (panel.Y+.5)/(panel.n+1.)
            panel["target_level"] = np.log(probability/(1-probability))
            panel["log_tests"] = np.log1p(panel.n)
            panel["quality"] = 1.
            task_id = "clinical_"+PATHOGENS.get(pathogen, str(len(self.tasks)))
            panel["label_id"] = [f"{task_id}:{x.date()}" for x in panel.end]
            frequency = "weekly" if weekly else "daily"
            history = {v: self.records(panel, v, 0, frequency, prefix=task_id) for v in VARIABLES["B"]}
            self.tasks.append(Task(task_id, "Clinical_unlocated" if not country else "Clinical_local",
                PATHOGENS.get(pathogen, pathogen), "rate", country, frequency,
                panel, history, "有效检测记录阳性率；非去重患者感染率",
                self.config.get("clinical_admin1"), self.config.get("clinical_air_city")))

    def build_overseas(self):
        raw = self.frames["ydyl_pathogen_overseas"]
        if raw.empty:
            return
        for index, spec in enumerate(self.config["overseas_series"]):
            d = raw[(raw.country_name == spec["country"]) & (raw.pathogen_name == spec["pathogen"])].copy()
            category = spec.get("category")
            d = d[d.category_name.isna()] if category is None else d[d.category_name == category]
            def sub_set(value):
                try:
                    return json.loads(value).get("sub_set") if pd.notna(value) else None
                except (ValueError, TypeError):
                    return None
            d["sub_set"] = d.metadata.map(sub_set)
            if spec.get("sub_set") is not None:
                d = d[d.sub_set == spec["sub_set"]]
            elif d.sub_set.nunique(dropna=False) > 1:
                self.reject("overseas:"+str(index), "混合多个来源系列，须明确 sub_set", len(d))
                continue
            v1, v2 = pd.to_numeric(d.indicator_value, errors="coerce"), pd.to_numeric(d.value, errors="coerce")
            conflicts = v1.notna() & v2.notna() & ~np.isclose(v1, v2, equal_nan=False)
            self.reject("overseas:"+str(index), "indicator_value 与 value 冲突", conflicts.sum())
            d["Y"] = v1.combine_first(v2)
            d["start"] = pd.to_datetime(d.period_start_date, errors="coerce").dt.normalize()
            d["end"] = pd.to_datetime(d.period_end_date, errors="coerce").dt.normalize()
            length = (d.end-d.start).dt.days+1
            if len(d) and not length.eq(7).all():
                spans = sorted(set(int(v) for v in length.dropna()))
                self.warn(f"{spec['country']} {spec['pathogen']} 含{spans}日原生区间；不折分为日/周标签。当前7日预测接口排除不匹配记录。")
            valid = (~conflicts & d.Y.ge(0) & np.isclose(d.Y, d.Y.round())
                     & length.eq(7) & d.indicator_name.eq("病例数"))
            self.reject("overseas:"+str(index), "非7日计数区间、负数或非整数", (~valid).sum())
            d = self._unique_domain(d[valid], ["start", "end"], ["Y"], "overseas:"+str(index))
            d = d.sort_values("start")
            # 不允许重叠区间造成同一原生标签重复计量。
            if len(d) > 1 and (d.start.iloc[1:].to_numpy() <= d.end.iloc[:-1].to_numpy()).any():
                self.reject("overseas:"+str(index), "原生区间重叠", len(d)); continue
            if d.empty:
                continue
            task_id = "overseas_"+str(index)
            d["available"] = d.end+pd.Timedelta(days=self.config["assumed_release_delay_days"]["pathogen"])
            d["n"], d["quality"] = np.nan, 1.
            d["label_id"] = [f"{task_id}:{x.date()}" for x in d.end]
            d["target_level"] = np.log1p(d.Y/7.)
            history = {v: [] for v in VARIABLES["B"]}
            history["target_level"] = self.records(d, "target_level", 0, "weekly", prefix=task_id)
            self.tasks.append(Task(task_id, spec["client"], PATHOGENS.get(spec["pathogen"], spec["pathogen"]),
                "count", country_name(spec["country"]), "weekly", d, history,
                f"{spec['country']} {spec['pathogen']} 原生7日监测计数；分类={category}; 子集={spec.get('sub_set')}"))

    def build_smooth(self):
        """兼容原研究目标：必须另提供可信、连续同口径日计数文件。
        config.smooth_tasks=[{file,client,country,pathogen}]；文件列 date,count。
        """
        for index, spec in enumerate(self.config.get("smooth_tasks", [])):
            d = pd.read_csv(self.optional/spec["file"])
            d["end"] = pd.to_datetime(d.date).dt.normalize()
            d["count"] = pd.to_numeric(d["count"], errors="coerce")
            d = self._unique_domain(d, ["end"], ["count"], "smooth")
            d = d.set_index("end").sort_index().asfreq("D")
            d["Y"] = d["count"].where(d["count"] >= 0).rolling(7, min_periods=7).mean()
            d = d.reset_index().dropna(subset=["Y"])
            d["start"] = d.end
            d["available"] = d.end+pd.Timedelta(days=self.config["assumed_release_delay_days"]["pathogen"])
            train = np.log1p(d.loc[d.available <= pd.Timestamp(self.config["train_end"]), "Y"])
            if not len(train):
                continue
            target_state = self.frozen_targets.get("smooth_"+str(index))
            mean, std = ((target_state["target_mean"], target_state["target_std"]) if target_state
                         else (float(train.mean()), max(float(train.std(ddof=0)), 1e-6)))
            d["target_level"] = (np.log1p(d.Y)-mean)/std
            d["Y"] = d.target_level
            d["n"], d["quality"] = np.nan, 1.
            task_id = "smooth_"+str(index)
            d["label_id"] = [f"{task_id}:{x.date()}" for x in d.end]
            history = {v: [] for v in VARIABLES["B"]}
            history["target_level"] = self.records(d, "target_level", 0, prefix=task_id)
            self.tasks.append(Task(task_id, spec["client"], spec["pathogen"], "smooth",
                country_name(spec.get("country")), "daily", d, history,
                "后向7日平均病例的训练段标准化 log1p 水平", target_mean=mean, target_std=std))

    def local_records(self, task, group, variable):
        if group == "B":
            return task.history[variable]
        if task.country is None:
            return []
        location = task.admin1 if group == "C" else task.air_city if group == "E" else None
        if location and group in ["C", "E"]:
            d = self.frames.get(group+"_locations", pd.DataFrame())
            region = "admin1_name" if group == "C" else "city"
            if not d.empty:
                panel = d[(d.country == task.country) & (d[region] == location)]
                return self.records(panel, variable,
                    self.config["assumed_release_delay_days"]["meteorology" if group == "C" else "air_quality"],
                    prefix=task.task_id+"_local")
        return self.public.get((task.country, group, variable), [])

    def aligned_group(self, key, records, calendar, group):
        cutoff = pd.Timestamp(self.config["train_end"])
        if self.frozen_scalers is not None:
            if key not in self.frozen_scalers:
                raise ValueError(f"已保存模型缺少 {key} 的标准化版本，需重新训练对应接口。")
            state = self.frozen_scalers[key]
            scaler = FrozenScaler(state["mean"], state["std"], state["native_records"])
        else:
            scaler = FrozenScaler.fit(records, cutoff)
        self.scalers[key] = scaler
        period_key = ("B_weekly" if records and records[0].frequency == "weekly" else "B_daily") if group == "B" else group
        return align_records(records, calendar, scaler, bool(records),
                             self.config["stop_carry_periods"][group], self.config["decay_per_period"],
                             period_days=self.config["normal_period_days"][period_key])

    def build_graph(self, calendar):
        nodes = COUNTRIES+sorted(k for k in self.geo_rows if k not in COUNTRIES)
        static = np.stack([np.stack([static_features(country_name(self.geo_rows.get(n, {}).get("country", n)),
                            self.geo_rows.get(n), day) for day in calendar]) for n in nodes], axis=1)
        node_groups = []
        node_support = []
        for n in nodes:
            features = []
            for group in ["C", "E", "V"]:
                for var in VARIABLES[group]:
                    records = self.public.get((n, group, var), [])
                    aligned, ids = self.aligned_group(f"graph:{n}:{group}:{var}", records, calendar, group)
                    # 公共图原始动态槽位乘质量，参考占位不通过偏置产生有效观测。
                    features.append(aligned)
            joined = np.concatenate(features, axis=1)
            node_groups.append(np.concatenate([joined, static[:, nodes.index(n)]], axis=1))
            node_support.append(np.maximum(joined[:, 4::13].mean(axis=1),
                                           static[:, nodes.index(n), 1:12:2].mean(axis=1)))
        self.graph_nodes = nodes
        self.graph_input = np.stack(node_groups, axis=1).astype(np.float32)
        self.graph_support = np.stack(node_support, axis=1).astype(np.float32)
        t, n = len(calendar), len(nodes)
        adjacency = np.zeros((t, 3, n, n), dtype=np.float32)  # target,source
        # 地理关系只在具有可信坐标且同层级的节点之间启用。
        for r, nr in enumerate(nodes):
            rr = self.geo_rows.get(nr, {})
            if not all(pd.notna(rr.get(k, np.nan)) for k in ["latitude", "longitude"]):
                continue
            r_release = pd.to_datetime(rr.get("available_at"), errors="coerce")
            if pd.isna(r_release):
                continue
            adjacency[calendar >= r_release, 0, r, r] = 1
            for s, ns in enumerate(nodes):
                ss = self.geo_rows.get(ns, {})
                if r == s or rr.get("level") != ss.get("level") or not all(
                    pd.notna(ss.get(k, np.nan)) for k in ["latitude", "longitude"]):
                    continue
                lat1, lat2 = np.radians([rr["latitude"], ss["latitude"]])
                a = np.sin((lat1-lat2)/2)**2+np.cos(lat1)*np.cos(lat2)*np.sin(np.radians(rr["longitude"]-ss["longitude"])/2)**2
                distance = 6371*2*np.arcsin(np.sqrt(np.clip(a, 0, 1)))
                s_release = pd.to_datetime(ss.get("available_at"), errors="coerce")
                if pd.notna(s_release):
                    adjacency[(calendar >= r_release) & (calendar >= s_release), 0, r, s] = np.exp(-distance/self.config["geo_distance_km"])
        for nr, row in self.geo_rows.items():
            parent = row.get("parent_id")
            release = pd.to_datetime(row.get("available_at"), errors="coerce")
            if parent in nodes and nr in nodes and pd.notna(release):
                adjacency[calendar >= release, 2, nodes.index(nr), nodes.index(parent)] = 1
        grouped = {}
        for source, target, record in self.edges:
            grouped.setdefault((source, target), []).append(record)
        for (source, target), records in grouped.items():
            # 边量不做本地 z 标准化；缺失与真零由可靠性区分。
            for i, day in enumerate(calendar):
                visible = [x for x in records if x.available <= day and x.end <= day]
                if not visible:
                    continue
                last = max(visible, key=lambda x: (x.end, x.available))
                age = (day-last.end).days/self.config["normal_period_days"]["V"]
                if age > self.config["stop_carry_periods"]["V"]:
                    continue
                reliable = math.exp(-self.config["decay_per_period"]*max(age-1, 0))
                adjacency[i, 1, nodes.index(target), nodes.index(source)] = reliable*np.log1p(last.value)
        adjacency /= np.maximum(adjacency.sum(axis=-1, keepdims=True), 1e-12)
        self.graph_adjacency = adjacency

    def future_features(self, task, origin):
        h = self.config["horizon_days"]
        features = np.zeros((h, 13*15), dtype=np.float32)
        rho = np.zeros((h, 1), dtype=np.float32)
        if self.forecasts.empty or task.country is None:
            return features, rho
        visible = self.forecasts[(self.forecasts.country == task.country) & (self.forecasts.issued_at <= origin)]
        variables = [(g, v) for g in ["C", "E", "V"] for v in VARIABLES[g]]
        for lead in range(h):
            day = origin+pd.Timedelta(days=lead+1)
            for j, (group, variable) in enumerate(variables):
                records = visible[(visible.variable == variable) & (visible.target_date == day)]
                if records.empty:
                    continue
                r = records.sort_values("issued_at").iloc[-1]
                if not np.isfinite(r.value):
                    continue
                scaler = self.scalers[f"{task.task_id}:{group}:{variable}"]
                x = features[lead, j*13:(j+1)*13]
                x[0] = np.clip((r.value-scaler.mean)/scaler.std, -20, 20)
                x[1:3] = 1; x[4] = .5; x[5] = 1; x[9] = 1
            rho[lead, 0] = features[lead, 4::13].mean()
        return features, rho

    def prepare(self):
        self.build_sources()
        first = min(t.labels.start.min() for t in self.tasks)-pd.Timedelta(days=self.config["history_days"])
        last = max(t.labels.end.max() for t in self.tasks)
        self.calendar = pd.date_range(first, last, freq="D")
        self.date_index = {d: i for i, d in enumerate(self.calendar)}
        self.build_graph(self.calendar)
        datasets = {"train": [], "validation": [], "test": []}
        self.task_features = {}
        for task in self.tasks:
            groups, support_ids = {}, {}
            for group in ["B", "C", "E", "V"]:
                channels, ids = [], []
                for var in VARIABLES[group]:
                    packed, supports = self.aligned_group(f"{task.task_id}:{group}:{var}",
                        self.local_records(task, group, var), self.calendar, group)
                    channels.append(packed); ids.append(supports)
                groups[group] = np.concatenate(channels, axis=1)
                support_ids[group] = ids
            static = static_features(task.country)
            self.task_features[task.task_id] = (groups, support_ids, static)
            candidates = self._origins(task)
            selected = {"train": [], "validation": [], "test": []}
            for origin, target_labels in candidates:
                if origin not in self.date_index:
                    continue
                split = self._split(target_labels, origin)
                if split:
                    selected[split].append((origin, target_labels))
            limit = self.config["max_train_windows_per_task"]
            if limit and len(selected["train"]) > limit:
                chosen = np.unique(np.linspace(0, len(selected["train"])-1, limit).round().astype(int))
                selected["train"] = [selected["train"][i] for i in chosen]
            for split, rows in selected.items():
                for origin, labels in rows:
                    sample = self.make_sample(task, origin, labels)
                    if sample is not None:
                        datasets[split].append(sample)
        self.audit["split_windows"] = {s: len(x) for s, x in datasets.items()}
        self.audit["feature_dictionary"] = VARIABLES
        self.audit["graph_nodes"] = self.graph_nodes
        self.audit["graph_private_clinical_records"] = False
        self.audit["default_environment_enabled"] = self.config["allow_country_station_proxy"]
        self.audit["split_rule"] = "所有客户端同一日历切分；跨界目标区间丢弃；训练标签发布时点也不得超出训练截止。"
        self.audit["scalers"] = {k: v.as_dict() for k, v in self.scalers.items()}
        return self.tasks, datasets

    def _origins(self, task):
        h = self.config["horizon_days"]
        if task.frequency == "weekly":
            return [(row.start-pd.Timedelta(days=1), [row._asdict()])
                    for row in task.labels.itertuples(index=False)]
        # 每 H 天一个不重叠目标窗口，未来标签可部分缺失，缺失日不制造 0。
        start, end = task.labels.start.min(), task.labels.end.max()
        candidates = []
        for day in pd.date_range(start, end-pd.Timedelta(days=h-1), freq=f"{h}D"):
            rows = task.labels[(task.labels.start >= day) & (task.labels.end < day+pd.Timedelta(days=h))]
            if not rows.empty:
                candidates.append((day-pd.Timedelta(days=1), rows.to_dict("records")))
        return candidates

    def _split(self, labels, origin):
        start = origin+pd.Timedelta(days=1)
        end = origin+pd.Timedelta(days=self.config["horizon_days"])
        # 完整 H 日预测区间也必须落在同一个评价段。
        train, valid = pd.Timestamp(self.config["train_end"]), pd.Timestamp(self.config["validation_end"])
        if end <= train and max(r["available"] for r in labels) <= train:
            return "train"
        if start > train and end <= valid:
            return "validation"
        if start > valid:
            return "test"
        return None

    def make_sample(self, task, origin, labels=None):
        l, h = self.config["history_days"], self.config["horizon_days"]
        idx = self.date_index[origin]
        if idx-l+1 < 0:
            return None
        groups, ids, static = self.task_features[task.task_id]
        static = static_features(task.country, self.geo_rows.get(task.admin1 or task.country), origin)
        window = slice(idx-l+1, idx+1)
        packed = {group: value[window].copy() for group, value in groups.items()}
        main = packed["B"][:, :13]
        unique_reports = len({x for x in ids["B"][0][idx-l+1:idx+1] if x})
        enabled = (unique_reports >= self.config["afd_min_native_reports"] and
                   np.mean(main[:, 4] > 0) >= self.config["afd_min_history_coverage"] and
                   maximum_run(main[:, 4] == 0) <= self.config["afd_max_reference_gap"])
        afd = decompose(main[:, 0], radii=self.config["afd_grid_radii"],
                        angles=self.config["afd_grid_angles"], enabled=enabled)
        packed["B"] = np.concatenate([packed["B"], afd.channels,
                                        np.full((l, 1), float(enabled))], axis=1).astype(np.float32)
        rho = {g: value[:, 4::13].mean(axis=1, keepdims=True) for g, value in packed.items() if g != "B"}
        rho["B"] = groups["B"][window, 4::13].mean(axis=1, keepdims=True)
        target_node_name = task.admin1 if task.admin1 in self.graph_nodes else task.country
        target_node = self.graph_nodes.index(target_node_name) if target_node_name in self.graph_nodes else 0
        graph_rho = np.zeros((l, 1), dtype=np.float32)
        relation_support = np.zeros((self.config["graph_layers"], 3), dtype=bool)
        if target_node_name in self.graph_nodes:
            for j, date_pos in enumerate(range(idx-l+1, idx+1)):
                reachable = {target_node}
                for layer in range(self.config["graph_layers"]-1, -1, -1):
                    following = set(reachable)
                    for relation in range(3):
                        for r in reachable:
                            neighbors = np.flatnonzero(self.graph_adjacency[date_pos, relation, r] > 0)
                            if len(neighbors):
                                relation_support[layer, relation] = True
                            following.update(neighbors.tolist())
                    reachable = following
                graph_rho[j, 0] = float(np.mean(self.graph_support[date_pos, list(reachable)]))
        future, future_rho = self.future_features(task, origin)
        future_dates = pd.date_range(origin+pd.Timedelta(days=1), periods=h)
        lead = np.concatenate([np.arange(1, h+1, dtype=np.float32)[:, None]/h,
                               calendar_features(future_dates)], axis=1)
        label_rows = []
        for r in labels or []:
            begin, finish = (r["start"]-origin).days-1, (r["end"]-origin).days
            if begin < 0 or finish > h or not np.isfinite(r["Y"]):
                continue
            if task.kind == "rate" and (not np.isfinite(r["n"]) or r["n"] <= 0 or r["Y"] > r["n"]):
                continue
            label_rows.append({"begin": begin, "finish": finish, "Y": float(r["Y"]),
                "n": float(r["n"]) if np.isfinite(r["n"]) else None, "quality": float(r["quality"]),
                "label_id": r["label_id"], "start": str(r["start"].date()), "end": str(r["end"].date())})
        return {"task": task.task_id, "client": task.client, "kind": task.kind,
            "pathogen": task.pathogen, "origin": str(origin.date()), "x": packed, "rho": rho,
            "static": static, "calendar": calendar_features(self.calendar[window]),
            "graph_x": self.graph_input[window].copy(), "adjacency": self.graph_adjacency[window].copy(),
            "graph_rho": graph_rho, "target_node": target_node,
            "relation_support": relation_support, "future": future, "future_rho": future_rho,
            "lead": lead, "labels": label_rows, "afd_enabled": enabled,
            "native_reports": unique_reports}

    def inference_sample(self, task, origin):
        # 当前工程预测起点必须在已建立的日历内；运行入口用最后标签日。
        return self.make_sample(task, pd.Timestamp(origin))
