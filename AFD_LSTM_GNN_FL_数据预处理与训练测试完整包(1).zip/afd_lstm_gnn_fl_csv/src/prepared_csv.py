"""两个可重建完整模型窗口的CSV：一行是某样本中的一个历史日。"""
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import os
import shutil
import tempfile

import numpy as np
import pandas as pd

from .data import DataBuilder, FrozenScaler, Task, VARIABLES, STATIC_FIELDS, dump_json

VERSION = "prepared-csv-1.0"
META = ["value", "native", "structural", "age", "quality", "observed", "carry",
        "interpolated", "reference", "daily", "weekly", "monthly", "other"]
PREPROCESS_KEYS = ["mode", "history_days", "horizon_days", "train_end", "validation_end",
    "max_train_windows_per_task", "afd_components", "afd_grid_radii", "afd_grid_angles",
    "afd_min_native_reports", "afd_min_history_coverage", "afd_max_reference_gap",
    "assumed_release_delay_days", "normal_period_days", "stop_carry_periods",
    "decay_per_period", "allow_country_weather_background", "allow_country_station_proxy",
    "strict_unknown_units", "clinical_country", "clinical_admin1", "clinical_air_city",
    "clinical_weekly_labels", "clinical_pathogens", "overseas_series", "smooth_tasks",
    "graph_layers", "geo_distance_km"]
IDENTITY = ["sample_id", "split", "task", "client", "kind", "pathogen", "country",
            "origin", "history_step", "history_date", "target_node", "afd_enabled",
            "native_reports", "label_count"]
TARGET_FIELDS = ["begin", "finish", "Y", "n", "quality", "label_id", "start", "end", "available"]


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for part in iter(lambda: f.read(1024*1024), b""):
            h.update(part)
    return h.hexdigest()


def preprocessing_config(config):
    return {k: config[k] for k in PREPROCESS_KEYS}


def feature_names(group):
    names = [f"{group}__{v}__{m}" for v in VARIABLES[group] for m in META]
    if group == "B":
        names += ["B__afd__"+v for v in ["history", "component1", "component2",
                                                   "component3", "residual", "enabled"]]
    return names


def make_layout(builder, config):
    # daily字段的顺序就是相应张量展平后的顺序，禁止按某个机构临时删列。
    daily = {"x."+g: feature_names(g) for g in VARIABLES}
    daily.update({"rho."+g: ["reliability__"+g] for g in VARIABLES})
    daily["calendar"] = ["calendar__"+v for v in ["annual_sin", "annual_cos", "weekly_sin", "weekly_cos"]]
    graph_variables = [name for g in ["C", "E", "V"] for name in feature_names(g)]
    static_names = [f"{f}__{v}" for f in STATIC_FIELDS for v in ["value", "available"]]
    graph_variables += ["static__"+n for n in static_names]
    daily["graph_x"] = [f"graph__n{i}__{v}" for i in range(len(builder.graph_nodes)) for v in graph_variables]
    daily["adjacency"] = [f"edge__{rel}__to{r}__from{s}" for rel in ["geo", "air", "admin"]
                            for r in range(len(builder.graph_nodes)) for s in range(len(builder.graph_nodes))]
    daily["graph_rho"] = ["reliability__graph"]
    first = {"static": ["static__"+n for n in static_names],
             "relation_support": [f"relation_support__l{i}__r{r}"
                                     for i in range(config["graph_layers"]) for r in range(3)]}
    source = [f"source__{g}__{v}" for g in VARIABLES for v in VARIABLES[g]]
    targets = [f"target_{i:02d}__{f}" for i in range(1, config["horizon_days"]+1) for f in TARGET_FIELDS]
    future = ["future_json", "future_rho_json", "lead_json"]
    columns = IDENTITY + [n for names in daily.values() for n in names] + source
    columns += [n for names in first.values() for n in names] + targets + future
    if len(set(columns)) != len(columns):
        raise ValueError("CSV列名重复。")
    return {"daily": daily, "first": first, "source": source, "targets": targets,
            "future": future, "columns": columns}


def _get(sample, path):
    value = sample
    for part in path.split("."):
        value = value[part]
    return value


def _set(sample, path, value):
    parts = path.split(".")
    if len(parts) == 1:
        sample[parts[0]] = value
    else:
        sample.setdefault(parts[0], {})[parts[1]] = value


def task_metadata(task):
    return {key: getattr(task, key) for key in ["task_id", "client", "pathogen", "kind", "country",
        "frequency", "description", "admin1", "air_city", "target_mean", "target_std"]}


def split_statistics(datasets, config):
    result = {}
    for split, samples in datasets.items():
        labels = [r for s in samples for r in s["labels"]]
        result[split] = {"windows": len(samples), "csv_rows": len(samples)*config["history_days"],
            "native_labels": len({r["label_id"] for r in labels}),
            "tasks": dict(Counter(s["task"] for s in samples)),
            "origin_min": min((s["origin"] for s in samples), default=None),
            "origin_max": max((s["origin"] for s in samples), default=None),
            "target_min": min((r["start"] for r in labels), default=None),
            "target_max": max((r["end"] for r in labels), default=None)}
    return result


def source_inventory(builder):
    inventory = []
    for entry in builder.audit["files"]:
        name = entry["name"]
        frame = builder.frames[Path(name).stem]
        record = {"name": name, "rows": len(frame), "columns": len(frame.columns),
                  "size_bytes": (builder.raw/name).stat().st_size,
                  "sha256": sha256(builder.raw/name),
                  "empty_cells": {k: int(v) for k, v in frame.isna().sum().items() if v},
                  "full_row_duplicates": int(frame.duplicated().sum())}
        date_column = next((k for k in ["obs_date", "date", "period_end_date", "month_id"] if k in frame), None)
        if date_column:
            dates = pd.to_datetime(frame[date_column].astype(str),
                                   format="%Y%m" if date_column == "month_id" else "mixed", errors="coerce")
            record.update(date_field=date_column, invalid_dates=int(dates.isna().sum()),
                          first_date=str(dates.min().date()), last_date=str(dates.max().date()))
        inventory.append(record)
    return inventory


def write_table(path, entries, tasks, builder, config, layout):
    task_by_id = {t.task_id: t for t in tasks}
    labels_by_id = {t.task_id: t.labels.set_index("label_id").to_dict("index") for t in tasks}
    row_count = 0
    # open文件句柄只写一次BOM，逐窗口写入避免数百MB的全表常驻内存。
    with Path(path).open("w", encoding="utf-8-sig", newline="") as stream:
        pd.DataFrame(columns=layout["columns"]).to_csv(stream, index=False)
        for split, sample in entries:
            length = config["history_days"]
            task = task_by_id[sample["task"]]
            base = {"sample_id": sample["task"]+":"+sample["origin"], "split": split,
                    **{k: sample[k] for k in ["task", "client", "kind", "pathogen", "origin",
                                              "target_node", "afd_enabled", "native_reports"]},
                    "country": task.country or "", "label_count": len(sample["labels"])}
            base["afd_enabled"] = int(base["afd_enabled"])
            data = {k: [v]*length for k, v in base.items()}
            data["history_step"] = np.arange(length)
            dates = pd.date_range(end=sample["origin"], periods=length)
            data["history_date"] = dates.strftime("%Y-%m-%d")
            for key, names in layout["daily"].items():
                values = np.asarray(_get(sample, key)).reshape(length, -1)
                if not np.isfinite(values).all() or values.shape[1] != len(names):
                    raise ValueError(f"窗口 {base['sample_id']} 的 {key} 非有限或维度不符。")
                data.update({n: values[:, i] for i, n in enumerate(names)})
            _, supports, _ = builder.task_features[task.task_id]
            first_index = builder.date_index[pd.Timestamp(sample["origin"])]-length+1
            for g in VARIABLES:
                for i, v in enumerate(VARIABLES[g]):
                    data[f"source__{g}__{v}"] = [x or "" for x in supports[g][i][first_index:first_index+length]]
            for key, names in layout["first"].items():
                values = np.asarray(sample[key]).ravel()
                for name, value in zip(names, values):
                    data[name] = [float(value)]+[""]*(length-1)
            for i, label in enumerate(sample["labels"], 1):
                native = labels_by_id[task.task_id][label["label_id"]]
                row = {**label, "available": str(pd.Timestamp(native["available"]).date())}
                for field in TARGET_FIELDS:
                    data[f"target_{i:02d}__{field}"] = [row[field] if row[field] is not None else ""]+[""]*(length-1)
            for key in ["future", "future_rho", "lead"]:
                data[key+"_json"] = [json.dumps(sample[key].tolist(), separators=(",", ":"), allow_nan=False)]+[""]*(length-1)
            frame = pd.DataFrame(data).reindex(columns=layout["columns"])
            frame.to_csv(stream, header=False, index=False, float_format="%.9g")
            row_count += length
    return row_count


def export_prepared(root, config):
    root = Path(root)
    destination = root/config.get("prepared_data_dir", "data/processed")
    destination.parent.mkdir(parents=True, exist_ok=True)
    builder = DataBuilder(root, config)
    tasks, datasets = builder.prepare()
    layout = make_layout(builder, config)
    statistics = split_statistics(datasets, config)
    print("对齐预处理完成，窗口数：", {k: v["windows"] for k, v in statistics.items()}, flush=True)
    # 全部文件先在同一磁盘临时目录完成；失败时不留下貌似可用的半个CSV。
    with tempfile.TemporaryDirectory(prefix="prepared_", dir=destination.parent) as temporary:
        temporary = Path(temporary)
        files = {}
        for filename, parts in [("train.csv", ["train", "validation"]), ("test.csv", ["test"])]:
            entries = [(split, sample) for split in parts for sample in datasets[split]]
            print("正在写入 "+filename, flush=True)
            rows = write_table(temporary/filename, entries, tasks, builder, config, layout)
            files[filename] = {"rows": rows, "windows": len(entries), "columns": len(layout["columns"]),
                               "size_bytes": (temporary/filename).stat().st_size,
                               "sha256": sha256(temporary/filename)}
        sample = next(s for part in datasets.values() for s in part)
        shapes = {key: list(np.asarray(_get(sample, key)).shape)
                  for key in list(layout["daily"])+list(layout["first"])+["future", "future_rho", "lead"]}
        manifest = {"format_version": VERSION, "config": preprocessing_config(config),
            "layout": layout, "shapes": shapes, "graph_nodes": builder.graph_nodes,
            "statistics": statistics, "files": files, "tasks": [task_metadata(t) for t in tasks],
            "sources": source_inventory(builder),
            "scalers": {k: v.as_dict() for k, v in builder.scalers.items()},
            "notes": {"row_unit": "one history day within one supervised window",
                      "validation_location": "train.csv contains split=train or validation",
                      "first_row_fields": "static, relation_support, all targets and future JSON only at history_step=0",
                      "overlapping_history": "past context may overlap across splits; native future labels do not overlap",
                      "future_forecasts": "new-data forecasts use predict_saved.py with raw files and frozen scalers"}}
        dump_json(temporary/"manifest.json", manifest)
        dump_json(temporary/"data_audit.json", builder.audit)
        dictionary = {"format_version": VERSION, "meta_channels": META,
                      "identity_columns": IDENTITY, "source_id_columns": layout["source"],
                      "history_input_columns": [n for ns in layout["daily"].values() for n in ns],
                      "first_row_input_columns": layout["first"],
                      "target_columns_never_model_inputs": layout["targets"]+["label_count"],
                      "future_columns": layout["future"], "graph_node_order": builder.graph_nodes,
                      "group_variables": VARIABLES,
                      "column_units": "value channels are training-only frozen transformed values; masks are dimensionless",
                      "blank_meaning": "blank outside first row is not another missing physical observation"}
        dump_json(temporary/"data_dictionary.json", dictionary)
        # Read back the files and compare every array, label and split before publication.
        _, loaded, _ = load_prepared(temporary, config)
        verification = compare_datasets(datasets, loaded)
        dump_json(temporary/"verification.json", verification)
        destination.mkdir(exist_ok=True)
        for path in sorted(temporary.iterdir(), key=lambda p: p.name == "manifest.json"):
            os.replace(path, destination/path.name)
    print("已生成并回读验证："+str(destination), flush=True)
    return destination, manifest


def _read_float_matrix(group, columns, shape):
    values = group[columns].to_numpy(dtype=np.float32)
    if not np.isfinite(values).all():
        raise ValueError("模型输入含空值或无穷数。")
    # pandas可能返回列主序内存；统一为C连续布局，避免相同值触发不同GEMM归约路径。
    return np.ascontiguousarray(values.reshape(shape))


class PreparedBuilder(SimpleNamespace):
    def inference_sample(self, task, origin):
        # 固定的监督CSV止于已导出窗口；新数据预测由predict_saved.py负责。
        return None


def load_prepared(directory, config):
    directory = Path(directory)
    manifest = json.loads((directory/"manifest.json").read_text(encoding="utf-8"))
    if manifest["format_version"] != VERSION:
        raise ValueError("预处理CSV格式版本不匹配，请重新运行prepare_data.py。")
    if manifest["config"] != preprocessing_config(config):
        raise ValueError("预处理配置已变化，请先重新运行prepare_data.py；不能用新配置解释旧CSV。")
    layout, shapes = manifest["layout"], manifest["shapes"]
    datasets = {k: [] for k in ["train", "validation", "test"]}
    native_by_task = {t["task_id"]: {} for t in manifest["tasks"]}
    for filename, allowed in [("train.csv", {"train", "validation"}), ("test.csv", {"test"})]:
        path = directory/filename
        if sha256(path) != manifest["files"][filename]["sha256"]:
            raise ValueError(f"{filename}校验不一致，请重新导出，不要直接改写已冻结数据。")
        text_columns = ["sample_id", "split", "task", "client", "kind", "pathogen", "country", "origin", "history_date"]
        text_columns += layout["source"]+layout["future"]
        text_columns += [n for n in layout["targets"] if n.endswith(("__label_id", "__start", "__end", "__available"))]
        frame = pd.read_csv(path, encoding="utf-8-sig", dtype={k: str for k in text_columns},
                            float_precision="round_trip", low_memory=False, keep_default_na=True)
        if list(frame.columns) != layout["columns"] or len(frame) != manifest["files"][filename]["rows"]:
            raise ValueError(filename+"字段或行数不符。")
        for sid, group in frame.groupby("sample_id", sort=False):
            group = group.sort_values("history_step")
            length = config["history_days"]
            if len(group) != length or not np.array_equal(group.history_step.to_numpy(), np.arange(length)):
                raise ValueError("历史窗口天数或序号不完整："+sid)
            first = group.iloc[0]
            if first["split"] not in allowed or any(group[k].nunique(dropna=False) != 1 for k in
                ["split", "task", "client", "kind", "pathogen", "origin", "target_node", "afd_enabled", "label_count"]):
                raise ValueError("窗口元数据不一致或集合错置："+sid)
            dates = pd.date_range(end=first.origin, periods=length).strftime("%Y-%m-%d")
            if list(group.history_date) != list(dates):
                raise ValueError("历史日期不连续或越过预测起点："+sid)
            sample = {k: str(first[k]) for k in ["task", "client", "kind", "pathogen", "origin"]}
            sample.update(target_node=int(first.target_node), afd_enabled=bool(first.afd_enabled),
                          native_reports=int(first.native_reports), labels=[])
            for key, names in layout["daily"].items():
                _set(sample, key, _read_float_matrix(group, names, shapes[key]))
            for key, names in layout["first"].items():
                values = first[names].to_numpy(dtype=np.float32).reshape(shapes[key])
                if not np.isfinite(values).all():
                    raise ValueError("首行输入缺失："+key)
                sample[key] = values.astype(bool) if key == "relation_support" else values
            for key in ["future", "future_rho", "lead"]:
                array = np.asarray(json.loads(first[key+"_json"]), dtype=np.float32)
                if list(array.shape) != shapes[key] or not np.isfinite(array).all():
                    raise ValueError("未来输入形状或数值错误："+key)
                sample[key] = array
            for i in range(1, int(first.label_count)+1):
                values = {f: first[f"target_{i:02d}__{f}"] for f in TARGET_FIELDS}
                row = {"begin": int(values["begin"]), "finish": int(values["finish"]),
                    "Y": float(values["Y"]), "n": None if pd.isna(values["n"]) else float(values["n"]),
                    "quality": float(values["quality"]),
                    **{k: str(values[k]) for k in ["label_id", "start", "end"]}}
                native = {"start": pd.Timestamp(values["start"]), "end": pd.Timestamp(values["end"]),
                          "available": pd.Timestamp(values["available"]), "Y": row["Y"],
                          "n": row["n"], "quality": row["quality"], "label_id": row["label_id"]}
                if row["label_id"] in native_by_task[sample["task"]]:
                    raise ValueError("同一原生标签被重复划入窗口："+row["label_id"])
                native_by_task[sample["task"]][row["label_id"]] = native
                sample["labels"].append(row)
            datasets[str(first["split"])].append(sample)
    validate_splits(datasets, manifest, native_by_task, config)
    tasks = [Task(**spec, labels=pd.DataFrame(list(native_by_task[spec["task_id"]].values())), history={})
             for spec in manifest["tasks"]]
    all_samples = [s for part in datasets.values() for s in part]
    latest = max(all_samples, key=lambda s: s["origin"])
    builder = PreparedBuilder(config=config, tasks=tasks, manifest=manifest,
        audit=json.loads((directory/"data_audit.json").read_text(encoding="utf-8")),
        scalers={k: FrozenScaler(v["mean"], v["std"], v["native_records"]) for k, v in manifest["scalers"].items()},
        graph_input=np.zeros((1, len(manifest["graph_nodes"]), shapes["graph_x"][-1]), dtype=np.float32),
        graph_nodes=manifest["graph_nodes"], graph_adjacency=latest["adjacency"],
        calendar=pd.date_range(end=latest["origin"], periods=config["history_days"]))
    return tasks, datasets, builder


def validate_splits(datasets, manifest, natives, config):
    seen = set()
    train_end, valid_end = pd.Timestamp(config["train_end"]), pd.Timestamp(config["validation_end"])
    for split, samples in datasets.items():
        for sample in samples:
            origin = pd.Timestamp(sample["origin"])
            start, end = origin+pd.Timedelta(days=1), origin+pd.Timedelta(days=config["horizon_days"])
            valid = (end <= train_end if split == "train" else
                     start > train_end and end <= valid_end if split == "validation" else start > valid_end)
            if not valid:
                raise ValueError("预测目标跨越集合边界。")
            for label in sample["labels"]:
                if label["label_id"] in seen:
                    raise ValueError("原生标签在不同样本或集合重复。")
                seen.add(label["label_id"])
                native = natives[sample["task"]][label["label_id"]]
                if split == "train" and native["available"] > train_end:
                    raise ValueError("训练标签在训练截止时尚不可用。")
                if (not 0 <= label["begin"] < label["finish"] <= config["horizon_days"] or
                    label["Y"] < 0 or not np.isfinite(label["Y"]) or
                    native["start"] != origin+pd.Timedelta(days=label["begin"]+1) or
                    native["end"] != origin+pd.Timedelta(days=label["finish"])):
                    raise ValueError("目标区间、数值或步长无效。")
                if sample["kind"] == "rate" and (label["n"] is None or label["n"] <= 0 or label["Y"] > label["n"]):
                    raise ValueError("阳性率标签分母无效。")
    statistics = split_statistics(datasets, config)
    if statistics != manifest["statistics"]:
        raise ValueError("回读后的样本统计与导出清单不符。")


def compare_datasets(original, restored):
    arrays, max_error, label_count = 0, 0., 0
    keys = ["x."+g for g in VARIABLES]+["rho."+g for g in VARIABLES]
    keys += ["static", "calendar", "graph_x", "adjacency", "graph_rho", "relation_support", "future", "future_rho", "lead"]
    for split in original:
        if len(original[split]) != len(restored[split]):
            raise AssertionError("CSV回读窗口数变化。")
        for left, right in zip(original[split], restored[split]):
            for key in ["task", "client", "kind", "pathogen", "origin", "target_node", "afd_enabled", "native_reports", "labels"]:
                if left[key] != right[key]:
                    raise AssertionError("CSV回读元信息或标签变化："+key)
            for key in keys:
                a, b = np.asarray(_get(left, key)), np.asarray(_get(right, key))
                error = float(np.max(np.abs(a.astype(float)-b.astype(float)))) if a.size else 0.
                max_error = max(max_error, error); arrays += 1
                if not np.array_equal(a, b):
                    raise AssertionError(f"CSV未无损恢复float32张量：{key}, error={error}")
            label_count += len(left["labels"])
    return {"passed": True, "compared_arrays": arrays, "native_labels": label_count,
            "max_absolute_array_error": max_error, "all_float32_arrays_exact": True,
            "checks": ["label_and_metadata_identity", "all_model_tensor_identity", "chronological_splits",
                       "native_label_disjointness", "history_dates", "file_hashes", "first_row_target_separation"]}
