"""AFD + LSTM + multi-relation GNN + module-aware federated learning."""
