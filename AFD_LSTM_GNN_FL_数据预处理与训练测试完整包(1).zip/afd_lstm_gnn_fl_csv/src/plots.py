"""运行自动保存各阶段诊断图；图件背景纯白，使用原生区间标签。"""
from pathlib import Path
from collections import defaultdict
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from .afd import decompose


def configure_fonts():
    plt.rcParams.update({"figure.facecolor": "white", "axes.facecolor": "white",
                         "savefig.facecolor": "white", "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.unicode_minus": False})


def create_diagnostics(builder, datasets, config, output, test_rows, history):
    configure_fonts()
    output = Path(output)/"figures"; output.mkdir(exist_ok=True)
    all_samples = datasets["train"]+datasets["validation"]+datasets["test"]
    if all_samples:
        supported = [s for s in all_samples if s["afd_enabled"]]
        sample = supported[-1] if supported else all_samples[-1]
        values = sample["x"]["B"][:, -6:-1]
        fig, axes = plt.subplots(5, 1, figsize=(10, 9), sharex=True)
        labels = ["History (scaled)", "AFD component 1", "AFD component 2",
                  "AFD component 3", "Residual"]
        colors = ["#202020", "#1368aa", "#188565", "#db6a27", "#8548a3"]
        for i, axis in enumerate(axes):
            axis.plot(values[:, i], color=colors[i]); axis.set_ylabel(labels[i])
            axis.grid(alpha=.15)
        axes[-1].set_xlabel("Historical calendar-day position")
        fig.suptitle(f"{sample['task']} | origin {sample['origin']} | AFD enabled={sample['afd_enabled']}")
        fig.tight_layout(); fig.savefig(output/"01_afd_decomposition.png", dpi=170); plt.close(fig)
        groups = ["B", "C", "E", "V", "G"]
        support = np.array([[float(s["rho"][g].mean()) if g != "G" else float(s["graph_rho"].mean())
                             for g in groups] for s in all_samples])
        fig, axis = plt.subplots(figsize=(8, 7))
        image = axis.imshow(support, aspect="auto", vmin=0, vmax=1, cmap="Blues", interpolation="nearest")
        axis.set_xticks(range(5), ["History", "Weather", "Environment", "Mobility", "Public GNN"])
        axis.set_ylabel("Window index (train, validation, test)")
        axis.set_title("Available-input reliability; zero is a closed branch")
        fig.colorbar(image, ax=axis, label="Mean pre-defined reliability")
        fig.tight_layout(); fig.savefig(output/"02_input_availability.png", dpi=170); plt.close(fig)
    adjacency = builder.graph_adjacency[-1]
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    for i, label in enumerate(["Geographic", "Directed aviation", "Administrative"]):
        axes[i].imshow(adjacency[i], vmin=0, vmax=1, cmap="Blues")
        axes[i].set_title(label)
        axes[i].set_xticks(range(len(builder.graph_nodes)), builder.graph_nodes, rotation=45, ha="right", fontsize=8)
        axes[i].set_yticks(range(len(builder.graph_nodes)), builder.graph_nodes, fontsize=8)
        axes[i].set_xlabel("Source"); axes[i].set_ylabel("Target")
    fig.suptitle(f"Incoming-normalized public relations as of {builder.calendar[-1].date()}")
    fig.tight_layout(); fig.savefig(output/"03_public_graph_relations.png", dpi=170); plt.close(fig)
    grouped = defaultdict(list)
    for row in test_rows:
        grouped[row["task"]].append(row)
    for task, rows in grouped.items():
        rows = sorted(rows, key=lambda x: x["target_end"])
        dates = pd.to_datetime([r["target_end"] for r in rows])
        fig, axis = plt.subplots(figsize=(11, 4.5))
        axis.plot(dates, [r["observed"] for r in rows], "o-", color="#1a202c", label="Observed native label", markersize=3)
        axis.plot(dates, [r["center"] for r in rows], "o-", color="#166baf", label="Prediction", markersize=3)
        axis.fill_between(dates, [r["low"] for r in rows], [r["high"] for r in rows], color="#3a9bc2", alpha=.18,
                          label="Nominal 95% prediction interval")
        axis.set_title(task+" | time-held-out engineering check")
        axis.set_ylabel(rows[0]["unit"]); axis.set_xlabel("Native target interval end")
        axis.grid(alpha=.15); axis.legend(fontsize=8)
        padding = pd.Timedelta(days=14 if rows[0]["kind"] == "count" else 3)
        axis.set_xlim(dates.min()-padding, dates.max()+padding)
        if rows[0]["kind"] == "rate":
            axis.set_ylim(0, 1)
            axis.text(.01, .02, "Intervals condition on observed test volume for evaluation only.",
                      transform=axis.transAxes, fontsize=8)
        fig.tight_layout(); fig.savefig(output/("04_test_"+task+".png"), dpi=170); plt.close(fig)
    if history:
        fig, axis = plt.subplots(figsize=(8, 4))
        clients = sorted(history[0]["clients"])
        for client in clients:
            points = [r["clients"][client]["loss"] for r in history]
            axis.plot(range(1, len(history)+1), points, "o-", label=client)
        axis.set_xlabel("Communication round"); axis.set_ylabel("Local optimization loss")
        axis.set_title("Engineering training trace (different task units)")
        axis.legend(); axis.grid(alpha=.15)
        fig.tight_layout(); fig.savefig(output/"05_federated_training.png", dpi=170); plt.close(fig)
