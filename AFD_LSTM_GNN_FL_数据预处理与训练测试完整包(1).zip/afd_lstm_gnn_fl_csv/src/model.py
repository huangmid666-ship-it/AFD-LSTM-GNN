"""固定 92 维融合、双层 64 维 LSTM、96 维任务条件与本地多口径头。"""
import math
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from .data import VARIABLES


def collate(samples, device="cpu"):
    def tensor(name, dtype=torch.float32):
        return torch.as_tensor(np.stack([s[name] for s in samples]), dtype=dtype, device=device)
    return {"x": {g: torch.as_tensor(np.stack([s["x"][g] for s in samples]), dtype=torch.float32, device=device)
                   for g in VARIABLES},
            "rho": {g: torch.as_tensor(np.stack([s["rho"][g] for s in samples]), dtype=torch.float32, device=device)
                    for g in VARIABLES},
            **{k: tensor(k) for k in ["static", "calendar", "graph_x", "adjacency", "graph_rho",
                                       "future", "future_rho", "lead"]},
            "target_node": tensor("target_node", torch.long), "samples": samples}


class ModalityEncoder(nn.Module):
    def __init__(self, input_width, gated=True):
        super().__init__()
        self.projection = nn.Linear(input_width, 16)
        self.gate = nn.Linear(17, 1) if gated else None

    def forward(self, x, rho):
        embedding = torch.tanh(self.projection(x))
        if self.gate is None:
            return embedding*(rho > 0).to(x.dtype)
        gate = rho*torch.sigmoid(self.gate(torch.cat([embedding, rho], dim=-1)))
        return embedding*gate


class RelationLayer(nn.Module):
    def __init__(self):
        super().__init__()
        self.self_transform = nn.Linear(16, 16)
        self.relations = nn.ModuleList([nn.Linear(16, 16, bias=False) for _ in range(3)])

    def forward(self, h, adjacency):
        result = self.self_transform(h)
        for i, relation in enumerate(self.relations):
            messages = torch.einsum("blrs,blsd->blrd", adjacency[:, :, i], relation(h))
            result = result+messages
        return F.relu(result)


class PublicGNN(nn.Module):
    def __init__(self, input_width, layers=2):
        super().__init__()
        self.input = nn.Linear(input_width, 16)
        self.layers = nn.ModuleList([RelationLayer() for _ in range(layers)])
        self.gate = nn.Linear(17, 1)

    def forward(self, x, adjacency, target_node, rho):
        # 原始数值乘来源可靠性；不可用参考数值不成为图观测。
        x = x.clone()
        for i in range(15):
            x[..., 13*i] = x[..., 13*i]*x[..., 13*i+4]
        h = torch.tanh(self.input(x))
        for layer in self.layers:
            h = layer(h, adjacency)
        batch, days = h.shape[:2]
        target = h[torch.arange(batch, device=x.device)[:, None],
                   torch.arange(days, device=x.device)[None, :], target_node[:, None]]
        gate = rho*torch.sigmoid(self.gate(torch.cat([target, rho], dim=-1)))
        return target*gate


class LocalTaskHead(nn.Module):
    def __init__(self, kind, initial_level):
        super().__init__()
        self.kind = kind
        self.metric_condition = nn.Parameter(torch.zeros(4))
        self.lead = nn.Linear(5, 4)
        self.network = nn.Sequential(nn.Linear(96, 32), nn.ReLU(),
                                     nn.Linear(32, 3 if kind == "smooth" else 2))
        with torch.no_grad():
            self.network[-1].weight.mul_(.01)
            bias = self.network[-1].bias
            bias.zero_()
            if kind == "count":
                # softplus^{-1}，仅来自训练标签，防止初始均值量级极端失配。
                level = max(initial_level, 1e-3)
                bias[0] = level+math.log(-math.expm1(-level))
                bias[1] = 5
            elif kind == "rate":
                p = min(max(initial_level, 1e-4), 1-1e-4)
                bias[0] = math.log(p/(1-p)); bias[1] = 10
            else:
                bias[0] = initial_level

    def forward(self, context):
        logits = self.network(context)
        if self.kind == "count":
            return {"mu": F.softplus(logits[..., 0])+1e-6,
                    "phi": F.softplus(logits[..., 1])+1e-4}
        if self.kind == "rate":
            return {"p": torch.sigmoid(logits[..., 0]).clamp(1e-6, 1-1e-6),
                    "nu": F.softplus(logits[..., 1])+1e-3}
        middle = logits[..., 0]
        return {"quantiles": torch.stack([middle-F.softplus(logits[..., 1]), middle,
                                           middle+F.softplus(logits[..., 2])], dim=-1)}


class ForecastModel(nn.Module):
    def __init__(self, tasks, graph_width, config):
        super().__init__()
        self.tasks = {t.task_id: t for t in tasks}
        self.pathogen_keys = {name: "p"+str(i) for i, name in enumerate(sorted({t.pathogen for t in tasks}))}
        self.shared = nn.ModuleDict({
            "B": ModalityEncoder(13*4+6, gated=False),
            "C": ModalityEncoder(13*8), "E": ModalityEncoder(13*6), "V": ModalityEncoder(13),
            "S": nn.Linear(18, 8), "T": nn.Linear(4, 4),
            "G": PublicGNN(graph_width, config["graph_layers"]),
            "LSTM": nn.LSTM(92, 64, num_layers=2, batch_first=True),
            "pathogens": nn.ParameterDict({key: nn.Parameter(torch.randn(8)*.02)
                                            for key in self.pathogen_keys.values()}),
            "future": ModalityEncoder(13*15),
        })
        cutoff = np.datetime64(config["train_end"])
        self.heads = nn.ModuleDict()
        for task in tasks:
            training = task.labels[task.labels.available.to_numpy() <= cutoff]
            if task.kind == "rate":
                level = float((training.Y.sum()+.5)/(training.n.sum()+1.))
            elif task.kind == "count":
                level = float(training.Y.mean()/7.) if len(training) else 1.
            else:
                level = float(training.Y.mean()) if len(training) else 0.
            self.heads[task.task_id] = LocalTaskHead(task.kind, level)

    def forward(self, batch, baseline=False, dropout_probability=0.):
        n, l = batch["calendar"].shape[:2]
        keep = {g: torch.ones((n, 1, 1), device=batch["calendar"].device) for g in ["C", "E", "V", "G", "future"]}
        for g in keep:
            if baseline:
                keep[g].zero_()
            elif self.training and dropout_probability > 0:
                keep[g] = (torch.rand((n, 1, 1), device=batch["calendar"].device) >= dropout_probability).float()
        embeddings = [self.shared["B"](batch["x"]["B"], batch["rho"]["B"])]
        for g in ["C", "E", "V"]:
            embeddings.append(self.shared[g](batch["x"][g], batch["rho"][g]*keep[g]))
        graph = self.shared["G"](batch["graph_x"], batch["adjacency"], batch["target_node"],
                                 batch["graph_rho"]*keep["G"])
        embeddings.append(graph)
        static = torch.tanh(self.shared["S"](batch["static"]))
        static = static*(batch["static"][:, 1::2].sum(dim=-1, keepdim=True) > 0)
        embeddings.extend([static[:, None, :].expand(-1, l, -1), torch.tanh(self.shared["T"](batch["calendar"]))])
        fused = torch.cat(embeddings, dim=-1)
        if fused.shape[-1] != 92:
            raise RuntimeError("固定槽位错误：LSTM 输入必须为92维。")
        sequence, _ = self.shared["LSTM"](fused)
        future = self.shared["future"](batch["future"], batch["future_rho"]*keep["future"])
        contexts, outputs = [], []
        for i, sample in enumerate(batch["samples"]):
            head = self.heads[sample["task"]]
            pathogen = self.shared["pathogens"][self.pathogen_keys[sample["pathogen"]]]
            h = future.shape[1]
            context = torch.cat([sequence[i, -1].expand(h, -1), pathogen.expand(h, -1),
                                 head.metric_condition.expand(h, -1), head.lead(batch["lead"][i]), future[i]], dim=-1)
            assert context.shape[-1] == 96
            contexts.append(context); outputs.append(head(context))
        return {"contexts": contexts, "outputs": outputs, "keep": keep, "fused": fused}

    def interval_parameters(self, result, sample_index, begin, finish, task_id):
        head = self.heads[task_id]
        context = result["contexts"][sample_index][begin:finish].mean(dim=0)
        params = head(context)
        if head.kind == "count":
            params["mu"] = result["outputs"][sample_index]["mu"][begin:finish].sum()
        return params


def parameter_block(name):
    """按真实路径细分图层/关系和病原体行；本地头不进入全局平均。"""
    if not name.startswith("shared."):
        return None
    key = name.removeprefix("shared.")
    if key.startswith("pathogens."):
        return key
    if key.startswith("G.layers."):
        tokens = key.split(".")
        layer = tokens[2]
        if tokens[3] == "relations":
            return f"G.relation.{layer}.{tokens[4]}"
        return f"G.self.{layer}"
    if key.startswith("G."):
        return ".".join(key.split(".")[:2])
    return key.split(".")[0]


def active_blocks(model, batch, result=None, baseline=False):
    blocks = {"T", "LSTM"}
    samples = batch["samples"]
    for sample in samples:
        if sample["labels"]:
            blocks.add("pathogens."+model.pathogen_keys[sample["pathogen"]])
    for g in ["B", "C", "E", "V"]:
        rho = batch["rho"][g]
        if g != "B":
            if baseline:
                continue
            if result is not None:
                rho = rho*result["keep"][g]
        if bool((rho > 0).any()):
            blocks.add(g)
    if bool(batch["static"][:, 1::2].any()):
        blocks.add("S")
    future_rho = batch["future_rho"]
    if result is not None:
        future_rho = future_rho*result["keep"]["future"]
    if not baseline and bool((future_rho > 0).any()):
        blocks.add("future")
    graph_rho = batch["graph_rho"]
    if result is not None:
        graph_rho = graph_rho*result["keep"]["G"]
    if not baseline and bool((graph_rho > 0).any()):
        blocks.update(["G.input", "G.gate"])
        for i in range(len(model.shared["G"].layers)):
            blocks.add(f"G.self.{i}")
            for relation in range(3):
                if any(s["relation_support"][i, relation] and
                       (result is None or bool(result["keep"]["G"][j].any()))
                       for j, s in enumerate(samples)):
                    blocks.add(f"G.relation.{i}.{relation}")
    return blocks
