"""有限网格 AFD：逐窗口 Hilbert 解析信号、核投影、Blaschke 递推。

AFD 系数属于预处理，不是 PyTorch 参数，不参与联邦聚合。
"""
from dataclasses import dataclass
import numpy as np
from scipy.signal import hilbert


@dataclass
class AFDResult:
    channels: np.ndarray  # [L, M+2] 原序列、排序分量、重构残差
    available: bool
    parameters: np.ndarray
    coefficients: np.ndarray
    frequency_centroids: np.ndarray


def decompose(values, components=3, radii=(0, .25, .5, .75, .9), angles=24,
              enabled=True):
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or len(values) < 2 or not np.isfinite(values).all():
        raise ValueError("AFD 需要至少两个有限实值的单变量样本。")
    if components != 3:
        raise ValueError("当前固定接口要求 M=3；修改 M 时必须同步历史编码接口。")
    if not enabled:
        channels = np.zeros((len(values), components+2), dtype=np.float32)
        channels[:, 0] = values
        return AFDResult(channels, False, np.array([]), np.array([]), np.zeros(components))
    if angles < 1 or any(r < 0 or r >= 1 for r in radii):
        raise ValueError("AFD 核候选必须位于单位圆内部。")
    candidates = np.unique(np.array([r*np.exp(2j*np.pi*k/angles)
                                     for r in radii for k in range(angles)]))
    xi = np.exp(2j*np.pi*np.arange(len(values))/len(values))
    kernels = np.sqrt(1-abs(candidates[:, None])**2)/(1-np.conj(candidates[:, None])*xi)
    remainder = hilbert(values)
    product = np.ones(len(values), dtype=np.complex128)
    params, coeffs, parts = [], [], []
    for _ in range(components):
        projection = np.mean(remainder[None, :]*np.conj(kernels), axis=1)
        best = int(np.argmax(abs(projection)**2))
        a, coefficient, kernel = candidates[best], projection[best], kernels[best]
        parts.append(np.real(coefficient*kernel*product))
        params.append(a); coeffs.append(coefficient)
        factor = (xi-a)/(1-np.conj(a)*xi)
        remainder = (remainder-coefficient*kernel)/factor
        product *= factor
    parts = np.array(parts)
    energy = abs(np.fft.rfft(parts, axis=1))**2
    frequencies = np.fft.rfftfreq(len(values))
    centers = (energy*frequencies).sum(axis=1)/(energy.sum(axis=1)+1e-12)
    centers[energy.sum(axis=1) < 1e-12] = np.inf
    order = np.argsort(centers, kind="stable")
    parts = parts[order]
    residual = values-parts.sum(axis=0)
    channels = np.column_stack([values, parts.T, residual]).astype(np.float32)
    return AFDResult(channels, True, np.array(params)[order],
                     np.array(coeffs)[order], centers[order])
