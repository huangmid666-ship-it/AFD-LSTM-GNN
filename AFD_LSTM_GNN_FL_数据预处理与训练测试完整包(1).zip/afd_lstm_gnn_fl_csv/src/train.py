"""原生标签监督、多缺省路径训练、激活块 FedProx 与联邦聚合。"""
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import random
import numpy as np
import pandas as pd
import torch
from scipy.stats import beta, betabinom, nbinom
from .data import dump_json, VARIABLES
from .model import collate, active_blocks, parameter_block


def negative_binomial_nll(y, mu, phi):
    y, mu, phi = y.double(), mu.double(), phi.double()
    return -(torch.lgamma(y+phi)-torch.lgamma(phi)-torch.lgamma(y+1)
             +phi*(torch.log(phi)-torch.log(phi+mu))
             +y*(torch.log(mu)-torch.log(phi+mu)))


def beta_binomial_nll(y, n, p, nu):
    y, n, p, nu = y.double(), n.double(), p.double(), nu.double()
    alpha, b = p*nu, (1-p)*nu
    log_choose = torch.lgamma(n+1)-torch.lgamma(y+1)-torch.lgamma(n-y+1)
    log_beta = lambda a, bb: torch.lgamma(a)+torch.lgamma(bb)-torch.lgamma(a+bb)
    return -(log_choose+log_beta(y+alpha, n-y+b)-log_beta(alpha, b))


def pinball_loss(y, quantiles):
    alpha = quantiles.new_tensor([.025, .5, .975])
    error = y-quantiles
    return torch.maximum(alpha*error, (alpha-1)*error).mean()


def supervised_loss(model, batch, result, task_weights):
    """每条真实原生区间只计算一次；未报告/n=0 不创建监督。"""
    groups = defaultdict(list)
    for i, sample in enumerate(batch["samples"]):
        for label in sample["labels"]:
            begin, finish = label["begin"], label["finish"]
            params = model.interval_parameters(result, i, begin, finish, sample["task"])
            context = result["contexts"][i]
            y = context.new_tensor(label["Y"])
            if sample["kind"] == "rate":
                if label["n"] is None or label["n"] <= 0:
                    continue
                n = context.new_tensor(label["n"])
                loss = beta_binomial_nll(y, n, params["p"], params["nu"])
            elif sample["kind"] == "count":
                loss = negative_binomial_nll(y, params["mu"], params["phi"])
            else:
                if finish-begin != 1:
                    raise ValueError("平滑任务需要真实每日目标，不能复制周标签。")
                loss = pinball_loss(y, params["quantiles"])
            groups[sample["kind"]].append((loss, label["quality"]))
    terms = []
    for kind, entries in groups.items():
        total = sum(weight for _, weight in entries)
        if total > 0:
            terms.append(task_weights[kind]*sum(loss*weight for loss, weight in entries)/total)
    return sum(terms).float() if terms else None


def schema(model, config):
    payload = {"version": "afd-lstm-gnn-fl-1.0", "variables": VARIABLES,
        "meta_order": ["value", "native", "structural", "age", "quality",
                       "observed", "carry", "interpolated", "reference",
                       "daily", "weekly", "monthly", "other"],
        "pathogen_keys": model.pathogen_keys,
        "history_days": config["history_days"], "horizon_days": config["horizon_days"],
        "graph_layers": config["graph_layers"],
        "shapes": {name: list(value.shape) for name, value in model.state_dict().items()
                   if name.startswith("shared.")}}
    payload["fingerprint"] = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    return payload


def shared_state(model):
    return {key: value.detach().cpu().clone() for key, value in model.state_dict().items()
            if key.startswith("shared.")}


def broadcast(model, state):
    current = model.state_dict()
    for name, value in state.items():
        if name not in current or tuple(value.shape) != tuple(current[name].shape):
            raise ValueError(f"联邦参数形状不匹配：{name}")
        current[name] = value.to(current[name].device)
    model.load_state_dict(current, strict=True)


def aggregate_modules(old_state, updates, expected_fingerprint, eta=.5):
    """无参与方保持上一轮；不平均本地输出头、AFD系数、标准化统计量。"""
    if not 0 <= eta <= 1:
        raise ValueError("aggregation_eta 必须位于0至1。")
    new_state = {k: v.clone() for k, v in old_state.items()}
    for update in updates:
        if update["fingerprint"] != expected_fingerprint:
            raise ValueError("拒绝不同语义字典/版本的客户端更新。")
        for name, value in update["state"].items():
            if name not in old_state or value.shape != old_state[name].shape:
                raise ValueError(f"拒绝未知参数或形状冲突：{name}")
            if not torch.isfinite(value).all():
                raise ValueError(f"拒绝非有限更新：{name}")
    log = {}
    blocks = sorted({parameter_block(k) for k in old_state})
    for block in blocks:
        candidates = [u for u in updates if u["effective"].get(block, 0) > 0]
        if not candidates:
            log[block] = {"clients": [], "weights": [], "action": "keep_previous"}
            continue
        weights = np.array([u["effective"][block]**eta for u in candidates], dtype=float)
        weights /= weights.sum()
        names = [name for name in old_state if parameter_block(name) == block]
        for name in names:
            if any(name not in u["state"] for u in candidates):
                raise ValueError(f"已申报激活块 {block} 缺少参数 {name}。")
            new_state[name] = sum(float(weight)*u["state"][name] for weight, u in zip(weights, candidates))
        log[block] = {"clients": [u["client"] for u in candidates], "weights": weights.tolist(),
                      "effective_units": [u["effective"][block] for u in candidates], "action": "aggregate"}
    return new_state, log


def support_ratio(block, sample, model):
    """先验有效量规则，既不是学习门控值，也不是事后误差。

    原生监督label_id去重；模态支持比例为窗口中有原生报告支持的变量日比例。
    低频沿用可支持一个标签的条件预测，但不增加新的label_id或原生报告数。
    """
    if block in ["T", "LSTM"]:
        return 1.
    if block.startswith("pathogens."):
        return float(block == "pathogens."+model.pathogen_keys[sample["pathogen"]])
    if block in ["B", "C", "E", "V"]:
        features = sample["x"][block]
        if block == "B":
            features = features[:, :13*len(VARIABLES["B"])]
        return float(np.mean(features[:, 4::13] > 0))
    if block == "S":
        return float(np.mean(sample["static"][1::2] > 0))
    if block == "future":
        return float(np.mean(sample["future_rho"] > 0))
    if block.startswith("G."):
        if block.startswith("G.relation."):
            _, _, layer, relation = block.split(".")
            if not sample["relation_support"][int(layer), int(relation)]:
                return 0.
        return float(np.mean(sample["graph_rho"] > 0))
    return 0.


def train_client(model, samples, global_state, config, device):
    model.train()
    samples = [s for s in samples if s["labels"]]
    if not samples:
        return {}, {"steps": 0, "loss": None, "reason": "no_true_labels"}
    # 优化器每一轮重新构造；无效块 grad=None，避免 Adam 动量/近端项制造更新。
    optimizer = torch.optim.Adam(model.parameters(), lr=config["learning_rate"], weight_decay=0.)
    effective = defaultdict(dict)
    losses = []
    reference = {k: v.to(device) for k, v in global_state.items()}
    for _ in range(config["local_epochs"]):
        order = list(samples); random.shuffle(order)
        for begin in range(0, len(order), config["batch_size"]):
            chosen = order[begin:begin+config["batch_size"]]
            batch = collate(chosen, device)
            optimizer.zero_grad(set_to_none=True)
            result = model(batch, dropout_probability=config["modality_dropout"])
            normal = supervised_loss(model, batch, result, config["task_loss_weights"])
            if normal is None:
                continue
            blocks = (active_blocks(model, batch, result)
                      if config["baseline_loss_weight"] < 1 else set())
            loss = normal
            if config["baseline_loss_weight"] > 0:
                baseline_result = model(batch, baseline=True)
                baseline_loss = supervised_loss(model, batch, baseline_result, config["task_loss_weights"])
                w = config["baseline_loss_weight"]
                loss = (1-w)*normal+w*baseline_loss
                blocks |= active_blocks(model, batch, baseline_result, baseline=True)
            proximal = loss.new_zeros(())
            for name, parameter in model.named_parameters():
                if parameter_block(name) in blocks:
                    proximal = proximal+(parameter-reference[name]).square().sum()
            loss = loss+config["fedprox_mu"]/2*proximal
            if not torch.isfinite(loss):
                raise FloatingPointError("本地损失非有限，停止训练并保留诊断。")
            loss.backward()
            active_tasks = {s["task"] for s in chosen if s["labels"]}
            for name, parameter in model.named_parameters():
                block = parameter_block(name)
                task = name.split(".")[1] if name.startswith("heads.") else None
                if (block is not None and block not in blocks) or (task is not None and task not in active_tasks):
                    parameter.grad = None
            torch.nn.utils.clip_grad_norm_(model.parameters(), config["gradient_clip"], error_if_nonfinite=True)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
            for block in blocks:
                for i, sample in enumerate(chosen):
                    # 某样本本次被随机遮蔽的外部分支不计作该块学习支持。
                    gate = (block if block in ["C", "E", "V", "future"]
                            else "G" if block.startswith("G.") else None)
                    if gate is not None and not bool(result["keep"][gate][i].any()):
                        continue
                    support = support_ratio(block, sample, model)
                    for label in sample["labels"]:
                        amount = label["quality"]*support
                        previous = effective[block].get(label["label_id"], 0.)
                        effective[block][label["label_id"]] = max(previous, amount)
    measures = {b: sum(v.values()) for b, v in effective.items() if sum(v.values()) > 0}
    # 如果共享块无真实路径支持，保证其参数精确保持下发版本。
    current = model.state_dict()
    for name in global_state:
        if parameter_block(name) not in measures:
            current[name] = global_state[name].to(device)
    model.load_state_dict(current)
    return measures, {"steps": len(losses), "loss": float(np.mean(losses)) if losses else None,
                       "unique_native_labels": len({r["label_id"] for s in samples for r in s["labels"]})}


def disable_untrained(batch, trained_blocks):
    """有接口但项目从未监督训练过的专用模块不参与正式工程预测。"""
    for group in ["B", "C", "E", "V"]:
        if group not in trained_blocks:
            batch["rho"][group].zero_()
    if "future" not in trained_blocks:
        batch["future_rho"].zero_()
    if "G.input" not in trained_blocks:
        batch["graph_rho"].zero_()
    if "S" not in trained_blocks:
        batch["static"].zero_()
    # 不关闭 LSTM/日历；对应任务未获监督时由入口明确跳过该头。


def distribution_record(model, result, index, sample, label, task):
    params = model.interval_parameters(result, index, label["begin"], label["finish"], sample["task"])
    p = {k: v.detach().cpu().numpy() for k, v in params.items()}
    row = {"client": sample["client"], "task": sample["task"], "pathogen": sample["pathogen"],
           "kind": sample["kind"], "origin": sample["origin"], "target_start": label["start"],
           "target_end": label["end"], "label_id": label.get("label_id"),
           "Y": label.get("Y"), "n": label.get("n"), "afd_enabled": sample["afd_enabled"],
           "native_history_reports": sample["native_reports"],
           "external_coverage": {g: float(sample["rho"][g].mean()) for g in ["C", "E", "V"]},
           "graph_coverage": float(sample["graph_rho"].mean())}
    if task.kind == "count":
        mu, phi = float(p["mu"]), float(p["phi"])
        low, high = nbinom.ppf([.025, .975], phi, phi/(phi+mu))
        row.update(center=mu, low=float(low), high=float(high), unit="native_interval_count",
                   mu=mu, phi=phi, observed=label.get("Y"), interval_semantics="negative_binomial_predictive")
    elif task.kind == "rate":
        probability, nu = float(p["p"]), float(p["nu"])
        lo, hi = beta.ppf([.025, .975], probability*nu, (1-probability)*nu)
        row.update(center=probability, low=float(lo), high=float(hi), unit="test_positivity_probability",
                   p=probability, nu=nu, probability_low=float(lo), probability_high=float(hi),
                   observed=None, interval_semantics="beta_latent_probability")
        if label.get("n") is not None and label["n"] > 0:
            n = int(label["n"])
            count_lo, count_hi = betabinom.ppf([.025, .975], n, probability*nu, (1-probability)*nu)
            # 对未来实测检测分母条件化仅用于回测；不送入预测模型。
            row.update(observed=label["Y"]/n, low=float(count_lo/n), high=float(count_hi/n),
                       predicted_count=probability*n, count_low=float(count_lo), count_high=float(count_hi),
                       interval_semantics="beta_binomial_rate_conditional_on_evaluation_n",
                       unit="test_positivity_fraction")
    else:
        q = p["quantiles"]
        q = np.maximum(np.expm1(np.clip(q*task.target_std+task.target_mean, -30, 30)), 0)
        observed = label.get("Y")
        if observed is not None:
            observed = max(float(np.expm1(observed*task.target_std+task.target_mean)), 0)
        row.update(center=float(q[1]), low=float(q[0]), high=float(q[2]), unit="backward_7day_mean_count",
                   observed=observed, interval_semantics="ordered_quantile_predictive")
    if not all(np.isfinite(row[key]) for key in ["center", "low", "high"]):
        raise FloatingPointError("预测分位数非有限，请检查训练/数据量级。")
    return row


def evaluate(models, samples, tasks, trained_blocks, trained_tasks, config, device):
    task_lookup = {t.task_id: t for t in tasks}
    grouped = defaultdict(list)
    for sample in samples:
        if sample["task"] in trained_tasks:
            grouped[sample["client"]].append(sample)
    rows, loss_by_kind = [], defaultdict(list)
    for client, selected in grouped.items():
        model = models[client]; model.eval()
        with torch.no_grad():
            for begin in range(0, len(selected), config["batch_size"]):
                batch = collate(selected[begin:begin+config["batch_size"]], device)
                disable_untrained(batch, trained_blocks)
                result = model(batch)
                for i, sample in enumerate(batch["samples"]):
                    for label in sample["labels"]:
                        rows.append(distribution_record(model, result, i, sample, label, task_lookup[sample["task"]]))
                loss = supervised_loss(model, batch, result, config["task_loss_weights"])
                if loss is not None:
                    loss_by_kind["balanced_batch_loss"].append(float(loss.cpu()))
    score = float(np.mean(loss_by_kind["balanced_batch_loss"])) if loss_by_kind else None
    return rows, score


def fit_interval_calibration(validation_rows, minimum=20):
    """时间验证残差的启发式扩宽，仅用于 count/smooth。
    不声称时间相关条件下严格 conformal 保证，不用测试标签校准。
    阳性率的分母相关分布保持原参数，不用全局扩宽伪称潜在概率覆盖。
    """
    groups = defaultdict(list)
    for row in validation_rows:
        if row["kind"] != "rate" and row["observed"] is not None:
            groups[row["task"]].append(max(row["low"]-row["observed"], row["observed"]-row["high"], 0.))
    output = {}
    for task, errors in groups.items():
        output[task] = {"n": len(errors), "margin": float(np.quantile(errors, .95, method="higher"))
                       if len(errors) >= minimum else 0., "applied": len(errors) >= minimum,
                       "semantics": "validation_only_heuristic_widening_no_temporal_coverage_guarantee"}
    return output


def apply_calibration(rows, calibration):
    for row in rows:
        entry = calibration.get(row["task"], {})
        margin = entry.get("margin", 0)
        row["uncalibrated_low"], row["uncalibrated_high"] = row["low"], row["high"]
        row["low"] = max(0., row["low"]-margin)
        row["high"] += margin
        row["calibration_applied"] = bool(entry.get("applied", False))
    return rows


def metrics(rows):
    grouped = defaultdict(list)
    for row in rows:
        if row["observed"] is not None:
            grouped[row["task"]].append(row)
    out = []
    for task, values in grouped.items():
        errors = np.array([x["center"]-x["observed"] for x in values])
        out.append({"task": task, "kind": values[0]["kind"], "n_native_labels": len(values),
            "mae": float(np.mean(abs(errors))), "rmse": float(np.sqrt(np.mean(errors**2))),
            "interval_coverage": float(np.mean([r["low"] <= r["observed"] <= r["high"] for r in values])),
            "interval_mean_width": float(np.mean([r["high"]-r["low"] for r in values])),
            "coverage_semantics": values[0]["interval_semantics"]})
    return out


def fit_federated(initial_model, datasets, tasks, builder, config, output, device):
    output = Path(output)
    clients = sorted({t.client for t in tasks})
    models = {client: deepcopy(initial_model).to(device) for client in clients}
    manifest = schema(initial_model, config)
    global_state = shared_state(initial_model)
    trained_blocks, trained_tasks = set(), set()
    history, best, best_score = [], None, float("inf")
    training = {c: [s for s in datasets["train"] if s["client"] == c] for c in clients}
    for round_index in range(config["rounds"]):
        updates, client_log = [], {}
        for client in clients:
            model = models[client]
            broadcast(model, global_state)
            measures, info = train_client(model, training[client], global_state, config, device)
            client_log[client] = {**info, "active_effective_units": measures}
            if measures:
                state = {key: value for key, value in shared_state(model).items()
                         if parameter_block(key) in measures}
                updates.append({"client": client, "state": state, "effective": measures,
                                "fingerprint": manifest["fingerprint"]})
                trained_blocks.update(measures)
                trained_tasks.update(s["task"] for s in training[client] if s["labels"])
        if not updates:
            raise ValueError("所有客户端均无真实监督更新，不能用随机模型输出正式预测。")
        global_state, module_log = aggregate_modules(global_state, updates, manifest["fingerprint"],
                                                     config["aggregation_eta"])
        for model in models.values():
            broadcast(model, global_state)
        validation_rows, score = evaluate(models, datasets["validation"], tasks, trained_blocks,
                                          trained_tasks, config, device)
        history.append({"round": round_index+1, "clients": client_log,
                        "module_aggregation": module_log, "validation_loss": score})
        print(f"联邦轮次 {round_index+1}/{config['rounds']} 完成，参与机构 {len(updates)}，验证损失 {score}", flush=True)
        if score is None or score < best_score:
            best_score = score if score is not None else best_score
            best = {"global": deepcopy(global_state), "models": {c: deepcopy(m.state_dict()) for c, m in models.items()},
                    "trained_blocks": set(trained_blocks), "trained_tasks": set(trained_tasks), "round": round_index+1}
    global_state, trained_blocks, trained_tasks = best["global"], best["trained_blocks"], best["trained_tasks"]
    for client in clients:
        models[client].load_state_dict(best["models"][client])
    validation_rows, _ = evaluate(models, datasets["validation"], tasks, trained_blocks, trained_tasks, config, device)
    calibration = fit_interval_calibration(validation_rows)
    test_rows, test_loss = evaluate(models, datasets["test"], tasks, trained_blocks, trained_tasks, config, device)
    apply_calibration(test_rows, calibration)
    forecasts = []
    task_by_id = {t.task_id: t for t in tasks}
    for task in tasks:
        if task.task_id not in trained_tasks:
            continue
        origin = task.labels.end.max()
        sample = builder.inference_sample(task, origin)
        if sample is None:
            continue
        model = models[task.client]; model.eval()
        batch = collate([sample], device); disable_untrained(batch, trained_blocks)
        with torch.no_grad():
            result = model(batch)
            if task.frequency == "weekly":
                intervals = [(0, config["horizon_days"])]
            else:
                intervals = [(i, i+1) for i in range(config["horizon_days"])]
            for begin, finish in intervals:
                label = {"begin": begin, "finish": finish, "Y": None, "n": None,
                         "start": str((origin+pd.Timedelta(days=begin+1)).date()),
                         "end": str((origin+pd.Timedelta(days=finish)).date())}
                row = distribution_record(model, result, 0, sample, label, task)
                row["trained_model_round"] = best["round"]
                row["data_status"] = "engineering_backtest_with_assumed_release_delays"
                forecasts.append(row)
    apply_calibration(forecasts, calibration)
    dump_json(output/"federated_history.json", history)
    dump_json(output/"schema.json", manifest)
    dump_json(output/"interval_calibration.json", calibration)
    dump_json(output/"validation_predictions.json", validation_rows)
    dump_json(output/"test_predictions.json", test_rows)
    dump_json(output/"forecasts.json", forecasts)
    for name, rows in [("validation_predictions", validation_rows), ("test_predictions", test_rows), ("forecasts", forecasts)]:
        table = pd.DataFrame(rows) if rows else pd.DataFrame(columns=[
            "client", "task", "kind", "origin", "target_start", "target_end", "center", "low", "high"])
        table.to_csv(output/(name+".csv"), index=False, encoding="utf-8-sig")
    summary = {"selected_round": best["round"], "test_loss": test_loss,
               "validation": metrics(validation_rows), "test": metrics(test_rows),
               "trained_tasks": sorted(trained_tasks), "trained_blocks": sorted(trained_blocks),
               "untrained_tasks_skipped": sorted(set(task_by_id)-trained_tasks),
               "forecast_note": "固定CSV用于训练和独立评价；新增原始数据的未来预测使用predict_saved.py。",
               "interpretation": "工程运行结果；3轮默认试跑不代表收敛或论文性能；无原报告性能沿用。"}
    dump_json(output/"metrics.json", summary)
    (output/"server").mkdir(exist_ok=True)
    torch.save({"shared_state": global_state, "schema": manifest, "config": config,
                "trained_blocks": sorted(trained_blocks), "round": best["round"]}, output/"server/shared.pt")
    for client, model in models.items():
        local_dir = output/"clients"/client; local_dir.mkdir(parents=True, exist_ok=True)
        ids = [t.task_id for t in tasks if t.client == client]
        local_heads = {k: v.detach().cpu() for k, v in model.state_dict().items()
                       if k.startswith("heads.") and k.split(".")[1] in ids}
        torch.save({"local_heads": local_heads, "schema_fingerprint": manifest["fingerprint"],
                    "task_ids": ids, "round": best["round"]}, local_dir/"local_heads.pt")
        dump_json(local_dir/"frozen_scalers.json", {k: v.as_dict() for k, v in builder.scalers.items()
                  if any(k.startswith(task+":") for task in ids) or k.startswith("graph:")})
        dump_json(local_dir/"task_metadata.json", [{"task": t.task_id, "kind": t.kind,
            "pathogen": t.pathogen, "country": t.country, "description": t.description,
            "target_mean": t.target_mean, "target_std": t.target_std} for t in tasks if t.client == client])
    return models, summary, test_rows, forecasts


def restore_client(model, server_path, local_path, expected_schema, device="cpu"):
    """只加载本项目自己生成的可信检查点；成套版本与字典检查。"""
    shared = torch.load(server_path, map_location=device, weights_only=True)
    local = torch.load(local_path, map_location=device, weights_only=True)
    fingerprint = expected_schema["fingerprint"]
    if shared["schema"]["fingerprint"] != fingerprint or local["schema_fingerprint"] != fingerprint:
        raise ValueError("检查点字典或模型版本不匹配。")
    if shared["round"] != local["round"]:
        raise ValueError("本地头与共享主干不是同一通信轮次。")
    broadcast(model, shared["shared_state"])
    state = model.state_dict()
    for name, value in local["local_heads"].items():
        if name not in state or state[name].shape != value.shape:
            raise ValueError("本地头形状不匹配。")
        state[name] = value.to(device)
    model.load_state_dict(state)
    return model
