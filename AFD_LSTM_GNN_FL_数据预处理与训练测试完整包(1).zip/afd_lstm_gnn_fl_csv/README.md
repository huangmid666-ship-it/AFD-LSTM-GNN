# AFD LSTM GNN FL 数据对齐与双CSV训练版

已处理随包8份原始CSV，共173,789条记录，生成data/processed/train.csv和test.csv。取消原每任务64个训练窗口的抽样上限后，训练353个窗口、验证52个、测试71个。

## Windows和PyCharm运行

1. 解压整个项目，使用Python 3.10及以上环境安装requirements.txt。
2. 右键运行prepare_data.py：只清洗、对齐、分解和导出CSV，不训练。
3. 右键运行run_project.py：从已经处理好的CSV训练并独立测试。
4. 右键运行run_tests.py：执行正确性及CSV回读检查。
5. 运行predict_saved.py：复用保存模型和冻结变换，处理新增原始数据并预测未来。

随包已有CSV，可以直接训练。CSV缺失时训练入口自动预处理；若改动时间窗口、源适配、缺失规则等预处理配置，请重新运行prepare_data.py。只改学习率或训练轮数不必重新制备数据。代码路径以脚本目录为基准，不依赖工作目录。requirements-tested.txt是实际验证版本，Windows不必安装Linux的CPU轮子。

## 两份CSV

| 文件和split | 数据行数 | 列数 | 模型窗口 | 原生目标标签 |
|---|---:|---:|---:|---:|
| train.csv / train | 19,768 | 1,051 | 353 | 1,174 |
| train.csv / validation | 2,912 | 1,051 | 52 | 218 |
| test.csv / test | 3,976 | 1,051 | 71 | 423 |

首行表头不计入行数。train.csv合计22,680行、405个窗口；验证样本不会参与参数训练。

**每行不是一个独立模型样本。** 每个sample_id包含56行历史，history_step为0—55，history_date截止origin。用这个长表结构可以在普通CSV中保存完整时序和图输入，避免展开成数万列。

target_01__Y等标签、静态条件及三列JSON只在history_step=0填值，其他行空白表示不重复存储。标签列不会送入模型。future_json、future_rho_json、lead_json仅保存未来条件、可用性和未来日历的小数组；历史与图特征全部是直接可读取的数值列。不需要另附NPZ数据。

## 处理和划分

- 临床逐病原统计真实Y与n，空白不视为阴性；境外按国家、病原、分类及来源子集筛选。
- 历史各日只读当日可见记录；当前多数源表无实际发布日志，保留假定延迟工程回测设置。
- 周病例保留周总量，月客流发布后作背景，不虚构日标签。
- 训练段拟合并冻结标准化，保存有限沿用、时间衰减、观测标记和来源频率。
- 每56日窗口计算AFD，保留原固定维度的历史、外部因素、静态、日历及GNN输入。
- 训练目标及可用时间不晚于2025-12-31；验证完整目标区间位于2026-01-01至03-31；测试目标区间从2026-04-01起。跨界目标区间丢弃。
- 历史上下文允许重叠，原生未来标签在集合间不重叠；未随机拆分重叠窗口。

国内临床缺经核实的地区字段，保持未定位，不强行拼当地环境。污染完成读取和适配但模型分支因空间及单位待核验关闭。巴西21/28日病例不拆成周标签；地理、物流缺项不填造。舆情文件不在随附8份输入中。

## 直接读取

```python
from pathlib import Path
import json
from src.prepared_csv import load_prepared
root = Path(__file__).resolve().parent
config = json.loads((root / 'config.json').read_text(encoding='utf-8'))
tasks, datasets, builder = load_prepared(root / 'data/processed', config)
# datasets['train']、['validation']、['test']直接用于原模型collate。
```

manifest.json保存样本量、字段布局、节点顺序、冻结变换及源文件/输出SHA256；data_dictionary.json明确输入与标签列；data_audit.json保存排除原因和时点假设；verification.json记录全部476窗口、1,815标签、8,092张量无损回读，float32最大误差0。

run_project.py从两个CSV读取固定训练/验证/测试输入，不重新打开原始表来构造训练样本，也不重新拟合标准化。结果保存在results下。默认三轮仅验证流程，不代表收敛或课题峰值指标达标；分任务实际误差见metrics.json。

固定CSV不制造未来未知标签，新数据预测使用predict_saved.py读取原始文件并复用保存的冻结变换。PT检查点只加载本项目自己生成的可信文件。
