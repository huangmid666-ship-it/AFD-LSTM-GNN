"""真实数据的CSV交付、读取及模型输入一致性。"""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd
import torch

from src.data import DataBuilder
from src.model import ForecastModel, collate
from src.prepared_csv import load_prepared, compare_datasets

ROOT = Path(__file__).resolve().parents[1]


class PreparedCSVTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.config = json.loads((ROOT/"config.json").read_text(encoding="utf-8"))
        cls.directory = ROOT/cls.config["prepared_data_dir"]
        cls.tasks, cls.datasets, cls.reader = load_prepared(cls.directory, cls.config)
        cls.builder = DataBuilder(ROOT, cls.config)
        _, cls.original = cls.builder.prepare()

    def test_every_array_and_label_survives_csv_roundtrip(self):
        result = compare_datasets(self.original, self.datasets)
        self.assertTrue(result["all_float32_arrays_exact"])
        self.assertEqual(result["max_absolute_array_error"], 0)

    def test_two_files_contain_all_unlimited_eligible_windows(self):
        self.assertEqual(self.config["max_train_windows_per_task"], 0)
        for split in self.datasets:
            self.assertEqual(len(self.datasets[split]), len(self.original[split]))
        self.assertGreater(len(self.datasets["train"]), 284)
        self.assertEqual(set(self.reader.manifest["files"]), {"train.csv", "test.csv"})

    def test_targets_are_not_feature_columns_or_repeated_observations(self):
        dictionary = json.loads((self.directory/"data_dictionary.json").read_text())
        inputs = set(dictionary["history_input_columns"])
        self.assertFalse(inputs & set(dictionary["target_columns_never_model_inputs"]))
        columns = ["history_step", "target_01__Y", "split"]
        frame = pd.read_csv(self.directory/"train.csv", usecols=columns)
        self.assertEqual(set(frame["split"]), {"train", "validation"})
        self.assertTrue(frame.loc[frame.history_step != 0, "target_01__Y"].isna().all())

    def test_loading_does_not_reopen_raw_tables_or_refit_scalers(self):
        with patch.object(DataBuilder, "prepare", side_effect=AssertionError("raw data must not be read")):
            tasks, _, builder = load_prepared(self.directory, self.config)
        self.assertEqual(len(tasks), 5)
        self.assertEqual({k: v.as_dict() for k, v in builder.scalers.items()},
                         self.reader.manifest["scalers"])

    def test_tensor_identity_preserves_actual_model_predictions(self):
        torch.manual_seed(17)
        torch.set_num_threads(2)
        model = ForecastModel(self.tasks, self.reader.graph_input.shape[-1], self.config).eval()
        original, restored = [], []
        for split in self.datasets:
            for kind in ["rate", "count"]:
                index = next(i for i, s in enumerate(self.datasets[split]) if s["kind"] == kind)
                original.append(self.original[split][index]); restored.append(self.datasets[split][index])
        with torch.no_grad():
            left, right = model(collate(original)), model(collate(restored))
        self.assertTrue(torch.equal(left["fused"], right["fused"]))
        for x, y in zip(left["outputs"], right["outputs"]):
            for name in x:
                self.assertTrue(torch.equal(x[name], y[name]))

    def test_changed_preprocessing_config_is_rejected(self):
        changed = copy.deepcopy(self.config); changed["history_days"] = 28
        with self.assertRaisesRegex(ValueError, "配置已变化"):
            load_prepared(self.directory, changed)

    def test_corrupted_or_partial_file_is_rejected_before_training(self):
        with tempfile.TemporaryDirectory() as tmp:
            temp = Path(tmp)
            (temp/"manifest.json").write_text((self.directory/"manifest.json").read_text())
            (temp/"train.csv").write_text("partial,file\n1,2\n")
            with self.assertRaisesRegex(ValueError, "校验不一致"):
                load_prepared(temp, self.config)


if __name__ == "__main__":
    unittest.main(verbosity=2)
