"""验证数学、时点、固定槽位与缺失参数资格，避免仅做表面形状测试。"""
import unittest
from pathlib import Path
from copy import deepcopy
import tempfile
import json
import numpy as np
import pandas as pd
import torch
from scipy.stats import nbinom, betabinom
from src.afd import decompose
from src.data import (Record, FrozenScaler, align_records, causal_interpolate, age_in_years, static_features,
                      Task, DataBuilder, calendar_features)
from src.model import ForecastModel, collate, active_blocks, RelationLayer, parameter_block
from src.train import (negative_binomial_nll, beta_binomial_nll, aggregate_modules,
                       train_client, shared_state, supervised_loss, schema, restore_client)

ROOT = Path(__file__).resolve().parents[1]


def config():
    c = json.loads((ROOT/"config.json").read_text(encoding="utf-8"))
    c.update(history_days=28, batch_size=2, local_epochs=1, modality_dropout=0.,
             baseline_loss_weight=.25, fedprox_mu=.1)
    return c


def task(kind="count", task_id="t0", pathogen="influenza_a"):
    labels = pd.DataFrame({"start": pd.to_datetime(["2025-01-06"]),
        "end": pd.to_datetime(["2025-01-12"]), "available": pd.to_datetime(["2025-01-19"]),
        "Y": [7.], "n": [10.], "quality": [1.], "label_id": [task_id+":1"]})
    return Task(task_id, "client", pathogen, kind, "Portugal", "weekly", labels,
                {}, "unit-test fixture")


def sample(kind="count", task_id="t0", pathogen="influenza_a", enabled=()):
    l, h, nodes = 28, 7, 3
    x = {"B": np.zeros((l, 58), np.float32), "C": np.zeros((l, 104), np.float32),
         "E": np.zeros((l, 78), np.float32), "V": np.zeros((l, 13), np.float32)}
    rho = {g: np.zeros((l, 1), np.float32) for g in x}
    for group in ["B"]+list(enabled):
        rho[group][:] = 1
        x[group][:, 4::13] = 1
    return {"task": task_id, "client": "client", "kind": kind, "pathogen": pathogen,
        "origin": "2025-01-05", "x": x, "rho": rho, "static": np.zeros(18, np.float32),
        "calendar": calendar_features(pd.date_range("2024-12-09", periods=l)),
        "graph_x": np.zeros((l, nodes, 213), np.float32),
        "adjacency": np.zeros((l, 3, nodes, nodes), np.float32),
        "graph_rho": np.zeros((l, 1), np.float32), "target_node": 1,
        "relation_support": np.zeros((2, 3), bool), "future": np.zeros((h, 195), np.float32),
        "future_rho": np.zeros((h, 1), np.float32), "lead": np.zeros((h, 5), np.float32),
        "labels": [{"begin": 0, "finish": 7, "Y": 7., "n": 10. if kind == "rate" else None,
                    "quality": 1., "label_id": task_id+":1", "start": "2025-01-06", "end": "2025-01-12"}],
        "afd_enabled": False, "native_reports": 4}


class AFDTests(unittest.TestCase):
    def test_exact_reconstruction_and_sorted_frequencies(self):
        x = .3*np.arange(56)/56+np.sin(2*np.pi*np.arange(56)/7)
        result = decompose(x)
        reconstructed = result.channels[:, 1:4].sum(axis=1)+result.channels[:, 4]
        np.testing.assert_allclose(reconstructed, x, atol=1e-6)
        self.assertTrue(np.all(np.diff(result.frequency_centroids) >= 0))
        self.assertTrue(np.all(abs(result.parameters) < 1))

    def test_disabled_retains_main_without_false_components(self):
        x = np.arange(28.)
        result = decompose(x, enabled=False)
        np.testing.assert_array_equal(result.channels[:, 0], x)
        self.assertFalse(result.available)
        self.assertEqual(np.count_nonzero(result.channels[:, 1:]), 0)

    def test_invalid_kernel_grid_rejected(self):
        with self.assertRaises(ValueError):
            decompose(np.arange(28.), radii=[1.0])


class AlignmentTests(unittest.TestCase):
    def test_age_months_and_days_are_not_mistaken_for_years(self):
        self.assertEqual(age_in_years("6月"), .5)
        self.assertEqual(age_in_years("1岁3月"), 1.25)
        self.assertAlmostEqual(age_in_years("30天"), 30/365.2425)
        self.assertTrue(np.isnan(age_in_years("未知")))

    def test_delayed_new_report_state_differs_from_old_carry(self):
        day = pd.Timestamp("2025-01-01")
        r = Record(day, day, day+pd.Timedelta(days=2), 10., "r")
        a, _ = align_records([r], pd.date_range(day, periods=4), FrozenScaler())
        self.assertEqual(a[2, 1], 0.)  # 未假装是当天原生事件
        self.assertEqual(a[2, 5], 1.)  # 当天新获实测值
        self.assertEqual(a[3, 6], 1.)  # 次日沿用

    def test_configured_normal_period_controls_staleness(self):
        day = pd.Timestamp("2025-01-01")
        r = Record(day, day, day, 10., "r", "weekly")
        a, _ = align_records([r], [day+pd.Timedelta(days=14)], FrozenScaler(), period_days=14)
        self.assertEqual(a[0, 3], 1.)

    def test_geographic_population_not_visible_before_release(self):
        row = {"population": 1000, "latitude": 10, "available_at": "2025-01-01"}
        before = static_features("Portugal", row, "2024-12-31")
        after = static_features("Portugal", row, "2025-01-01")
        self.assertEqual(before[5], 0.)  # 人口项可用标记
        self.assertEqual(after[5], 1.)
        self.assertGreater(after[4], 0.)

    def test_no_early_release_and_no_historical_rewrite(self):
        days = pd.date_range("2025-01-01", periods=5)
        r = Record(days[0], days[0], days[2], 10., "r")
        a, ids = align_records([r], days, FrozenScaler(), stop_periods=7)
        self.assertEqual(float(a[0, 4]), 0.)
        self.assertEqual(float(a[1, 0]), 0.)
        self.assertGreater(float(a[2, 4]), 0.)
        self.assertEqual(ids[0], None)
        self.assertEqual(ids[2], "r")

    def test_true_zero_vs_missing(self):
        day = pd.Timestamp("2025-01-01")
        actual, _ = align_records([Record(day, day, day, 0., "zero")], [day], FrozenScaler())
        absent, _ = align_records([], [day], FrozenScaler(), structural=False)
        self.assertEqual(actual[0, 0], absent[0, 0])
        self.assertEqual(actual[0, 1], 1)
        self.assertEqual(absent[0, 1], 0)
        self.assertEqual(actual[0, 4], 1)
        self.assertEqual(absent[0, 4], 0)

    def test_weekly_carry_not_seven_independent_reports(self):
        day = pd.Timestamp("2025-01-01")
        r = Record(day-pd.Timedelta(days=6), day, day, 10., "one-week", "weekly")
        a, ids = align_records([r], pd.date_range(day, periods=7), FrozenScaler())
        self.assertEqual(len(set(ids)), 1)
        self.assertEqual(a[:, 1].sum(), 1)
        self.assertEqual(a[:, 10].sum(), 7)  # weekly 频率槽位

    def test_stale_stops_carry_and_returns_reference(self):
        day = pd.Timestamp("2025-01-01")
        r = Record(day, day, day, 8., "r")
        a, _ = align_records([r], [day+pd.Timedelta(days=8)], FrozenScaler(), stop_periods=7)
        self.assertEqual(a[0, 0], 0.)
        self.assertEqual(a[0, 4], 0.)
        self.assertEqual(a[0, 8], 1.)

    def test_scaler_ignores_future_values_and_late_reports(self):
        day = pd.Timestamp("2025-01-01")
        r = [Record(day, day, day, 5., "a"),
             Record(day, day, day+pd.Timedelta(days=20), 999., "b")]
        fitted = FrozenScaler.fit(r, day)
        self.assertEqual(fitted.mean, 5.)
        self.assertEqual(fitted.count, 1)

    def test_interpolation_requires_both_visible_endpoints(self):
        values = [1., 3.]; dates = ["2025-01-01", "2025-01-03"]
        self.assertIsNone(causal_interpolate(values, dates, dates, "2025-01-02", "2025-01-02"))
        self.assertEqual(causal_interpolate(values, dates, dates, "2025-01-02", "2025-01-03"), 2.)

    def test_split_does_not_cross_calendar_boundary_with_missing_labels(self):
        b = DataBuilder(ROOT, config())
        r = [{"start": pd.Timestamp("2025-12-30"), "end": pd.Timestamp("2025-12-30"),
              "available": pd.Timestamp("2025-12-31")}]
        self.assertIsNone(b._split(r, pd.Timestamp("2025-12-28")))

    def test_blank_clinical_is_not_negative(self):
        b = DataBuilder(ROOT, config())
        b.frames["ydyl_clinical_domestic"] = pd.DataFrame({"date": ["2025-01-01"]*3,
            "age": ["30岁"]*3, "sex": ["女"]*3, "甲型流感病毒": ["阳性", "阴性", None]})
        b.build_clinical()
        t = b.tasks[0]
        self.assertEqual(t.labels.n.iloc[0], 2)
        self.assertEqual(t.labels.Y.iloc[0], 1)
        self.assertIsNone(t.country)


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def test_fixed_slots_and_finite_backward_when_external_absent(self):
        model = ForecastModel([task()], 213, config())
        batch = collate([sample()]); result = model(batch)
        self.assertEqual(tuple(result["fused"].shape), (1, 28, 92))
        self.assertEqual(result["contexts"][0].shape[-1], 96)
        self.assertEqual(tuple(model.shared["LSTM"].weight_ih_l0.shape), (256, 92))
        # PyTorch 把4个64行门矩阵堆成256行；单门仍是64×92。
        self.assertEqual(torch.count_nonzero(result["fused"][..., 16:80]), 0)
        loss = supervised_loss(model, batch, result, config()["task_loss_weights"])
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        self.assertTrue(torch.isfinite(model.shared["LSTM"].weight_ih_l0.grad).all())

    def test_weekly_count_likelihood_has_one_native_term(self):
        model = ForecastModel([task()], 213, config())
        batch = collate([sample()]); result = model(batch)
        params = model.interval_parameters(result, 0, 0, 7, "t0")
        actual = supervised_loss(model, batch, result, config()["task_loss_weights"])
        expected = negative_binomial_nll(torch.tensor(7.), params["mu"], params["phi"])
        self.assertAlmostEqual(float(actual.detach()), float(expected.detach()), places=5)
        self.assertAlmostEqual(float(params["mu"].detach()), float(result["outputs"][0]["mu"].sum().detach()), places=5)

    def test_missing_modules_and_unused_pathogen_row_do_not_move(self):
        tasks = [task(), task(task_id="t1", pathogen="influenza_b")]
        model = ForecastModel(tasks, 213, config()); previous = shared_state(model)
        before = {k: v.clone() for k, v in model.state_dict().items()}
        measures, info = train_client(model, [sample()], previous, config(), "cpu")
        self.assertGreater(info["steps"], 0)
        for key, value in model.state_dict().items():
            block = parameter_block(key)
            if block in ["E", "V", "C", "future", "pathogens.p1"] or key.startswith("heads.t1."):
                self.assertTrue(torch.equal(value, before[key]), key)
        self.assertNotIn("E", measures)
        self.assertNotIn("pathogens.p1", measures)
        self.assertIn("LSTM", measures)

    def test_no_labels_produces_no_update(self):
        model = ForecastModel([task()], 213, config()); state = deepcopy(model.state_dict())
        s = sample(); s["labels"] = []
        effective, info = train_client(model, [s], shared_state(model), config(), "cpu")
        self.assertEqual(effective, {})
        self.assertEqual(info["steps"], 0)
        for key in state:
            self.assertTrue(torch.equal(state[key], model.state_dict()[key]))

    def test_available_environment_is_updated_but_fully_missing_is_not(self):
        model = ForecastModel([task()], 213, config())
        original = shared_state(model)
        c = config();c["baseline_loss_weight"] = 0
        amounts, _ = train_client(model, [sample(enabled=["E"])], original, c, "cpu")
        self.assertIn("E", amounts)
        self.assertFalse(torch.equal(original["shared.E.projection.weight"], model.state_dict()["shared.E.projection.weight"]))
        original = shared_state(model)
        amounts, _ = train_client(model, [sample()], original, c, "cpu")
        self.assertNotIn("E", amounts)
        self.assertTrue(torch.equal(original["shared.E.projection.weight"], model.state_dict()["shared.E.projection.weight"]))

    def test_baseline_closes_future_background_without_closing_calendar(self):
        model = ForecastModel([task()], 213, config())
        s = sample();s["future_rho"][:] = 1;s["future"][:] = 1
        batch = collate([s]); normal = model(batch); baseline = model(batch, baseline=True)
        self.assertGreater(int(torch.count_nonzero(normal["contexts"][0][:, -16:])), 0)
        self.assertEqual(int(torch.count_nonzero(baseline["contexts"][0][:, -16:])), 0)
        blocks = active_blocks(model, batch, baseline, baseline=True)
        self.assertNotIn("future", blocks);self.assertIn("T", blocks)

    def test_directed_graph_only_source_to_target(self):
        layer = RelationLayer()
        with torch.no_grad():
            layer.self_transform.weight.zero_(); layer.self_transform.bias.zero_()
            for relation in layer.relations:
                relation.weight.zero_()
            layer.relations[1].weight.copy_(torch.eye(16))
        h = torch.zeros(1, 1, 3, 16); h[0, 0, 0] = 2
        a = torch.zeros(1, 1, 3, 3, 3); a[0, 0, 1, 1, 0] = 1
        result = layer(h, a)
        self.assertTrue(torch.equal(result[0, 0, 1], h[0, 0, 0]))
        self.assertEqual(torch.count_nonzero(result[0, 0, 0]), 0)

    def test_smooth_quantiles_are_ordered(self):
        model = ForecastModel([task(kind="smooth")], 213, config())
        s = sample(kind="smooth");s["labels"] = []
        q = model(collate([s]))["outputs"][0]["quantiles"]
        self.assertTrue(bool((q[:, 0] <= q[:, 1]).all()))
        self.assertTrue(bool((q[:, 1] <= q[:, 2]).all()))

    def test_checkpoint_pair_reloads_identically(self):
        model = ForecastModel([task()], 213, config()); expected = schema(model, config())
        with tempfile.TemporaryDirectory() as name:
            p = Path(name)
            torch.save({"shared_state": shared_state(model), "schema": expected, "round": 1}, p/"server.pt")
            torch.save({"local_heads": {k: v for k, v in model.state_dict().items() if k.startswith("heads.")},
                        "schema_fingerprint": expected["fingerprint"], "round": 1}, p/"local.pt")
            restored = ForecastModel([task()], 213, config())
            restore_client(restored, p/"server.pt", p/"local.pt", expected)
            for key in model.state_dict():
                self.assertTrue(torch.equal(model.state_dict()[key], restored.state_dict()[key]))


class DistributionTests(unittest.TestCase):
    def test_negative_binomial_matches_scipy(self):
        for y in [0., 8., 10000.]:
            actual = negative_binomial_nll(torch.tensor(y), torch.tensor(12.), torch.tensor(4.))
            expected = -nbinom.logpmf(y, 4., 4./16.)
            self.assertAlmostEqual(float(actual.detach()), expected, places=7)

    def test_beta_binomial_matches_scipy_and_finite_gradient(self):
        for y in [0., 5., 10.]:
            p = torch.tensor(.3, dtype=torch.float64, requires_grad=True)
            nu = torch.tensor(8., dtype=torch.float64, requires_grad=True)
            actual = beta_binomial_nll(torch.tensor(y), torch.tensor(10.), p, nu)
            self.assertAlmostEqual(float(actual.detach()), -betabinom.logpmf(y, 10, 2.4, 5.6), places=7)
            actual.backward()
            self.assertTrue(torch.isfinite(p.grad));self.assertTrue(torch.isfinite(nu.grad))


class AggregationTests(unittest.TestCase):
    def test_missing_client_excluded_per_module_and_empty_keeps_old(self):
        old = {"shared.E.projection.weight": torch.tensor([7.]),
               "shared.V.projection.weight": torch.tensor([9.]),
               "shared.LSTM.weight": torch.tensor([0.])}
        updates = [{"client": "A", "fingerprint": "schema", "effective": {"E": 1., "LSTM": 1.},
                    "state": {"shared.E.projection.weight": torch.tensor([2.]), "shared.LSTM.weight": torch.tensor([2.])}},
                   {"client": "B", "fingerprint": "schema", "effective": {"E": 0., "LSTM": 3.},
                    "state": {"shared.E.projection.weight": torch.tensor([1000.]), "shared.LSTM.weight": torch.tensor([6.])}}]
        new, log = aggregate_modules(old, updates, "schema", eta=1.)
        self.assertEqual(float(new["shared.E.projection.weight"]), 2.)
        self.assertEqual(float(new["shared.V.projection.weight"]), 9.)
        self.assertEqual(float(new["shared.LSTM.weight"]), 5.)
        self.assertEqual(log["E"]["clients"], ["A"])

    def test_wrong_schema_rejected(self):
        with self.assertRaises(ValueError):
            aggregate_modules({}, [{"client": "A", "fingerprint": "wrong", "effective": {}, "state": {}}], "correct")

    def test_claimed_block_without_parameter_rejected(self):
        with self.assertRaises(ValueError):
            aggregate_modules({"shared.E.weight": torch.tensor([0.])},
                [{"client": "A", "fingerprint": "same", "effective": {"E": 1.}, "state": {}}], "same")


if __name__ == "__main__":
    unittest.main(verbosity=2)
