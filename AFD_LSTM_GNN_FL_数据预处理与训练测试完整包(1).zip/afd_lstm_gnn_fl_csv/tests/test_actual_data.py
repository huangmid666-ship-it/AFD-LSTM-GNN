"""使用随包真实CSV核对接口；不检验或承诺预测性能。"""
import unittest
import json
from pathlib import Path
import numpy as np
import pandas as pd
from src.data import DataBuilder, Task, Record

ROOT = Path(__file__).resolve().parents[1]


class ActualDataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.config = json.loads((ROOT/"config.json").read_text(encoding="utf-8"))
        cls.builder = DataBuilder(ROOT, cls.config)
        cls.tasks, cls.datasets = cls.builder.prepare()

    def test_unlocated_clinical_never_receives_country_exposure(self):
        selected = [s for split in self.datasets.values() for s in split if s["client"] == "Clinical_unlocated"]
        self.assertTrue(selected)
        for s in selected:
            self.assertEqual(np.count_nonzero(s["static"]), 0)
            self.assertEqual(float(s["graph_rho"].sum()), 0.)
            for g in ["C", "E", "V"]:
                self.assertEqual(float(s["rho"][g].sum()), 0.)

    def test_brazil_28day_rolling_records_are_not_faked_as_weekly(self):
        raw = self.builder.frames["ydyl_pathogen_overseas"]
        selected = raw[raw.pathogen_name == "SARS-CoV-2"]
        spans = (pd.to_datetime(selected.period_end_date)-pd.to_datetime(selected.period_start_date)).dt.days+1
        self.assertTrue(spans.eq(28).any())
        self.assertFalse(spans.eq(7).any())
        self.assertFalse(any(t.task_id == "overseas_2" for t in self.tasks))

    def test_no_environment_observations_created_without_spatial_mapping(self):
        for split in self.datasets.values():
            for s in split:
                self.assertEqual(float(s["rho"]["E"].sum()), 0.)

    def test_native_label_ids_disjoint_and_splits_follow_global_calendar(self):
        ids = {}
        train_end = pd.Timestamp(self.config["train_end"])
        valid_end = pd.Timestamp(self.config["validation_end"])
        for name, split in self.datasets.items():
            ids[name] = set()
            for s in split:
                origin = pd.Timestamp(s["origin"])
                end = origin+pd.Timedelta(days=self.config["horizon_days"])
                if name == "train":
                    self.assertLessEqual(end, train_end)
                elif name == "validation":
                    self.assertGreater(origin+pd.Timedelta(days=1), train_end)
                    self.assertLessEqual(end, valid_end)
                else:
                    self.assertGreater(origin+pd.Timedelta(days=1), valid_end)
                for label in s["labels"]:
                    self.assertNotIn(label["label_id"], ids[name])
                    ids[name].add(label["label_id"])
        self.assertFalse(ids["train"] & ids["validation"])
        self.assertFalse(ids["train"] & ids["test"])
        self.assertFalse(ids["validation"] & ids["test"])

    def test_future_forecast_version_never_reads_later_issue(self):
        task = next(t for t in self.tasks if t.country == "Portugal")
        origin = pd.Timestamp("2026-01-01")
        self.builder.forecasts = pd.DataFrame({"country": ["Portugal"],
            "issued_at": [origin+pd.Timedelta(days=1)], "target_date": [origin+pd.Timedelta(days=1)],
            "variable": ["temp_mean"], "value": [999.]})
        x, rho = self.builder.future_features(task, origin)
        self.assertEqual(float(rho.sum()), 0.)
        self.builder.forecasts = pd.DataFrame()

    def test_saved_scaler_reuse_is_exact(self):
        key = next(iter(self.builder.scalers))
        all_saved = {k: v.as_dict() for k, v in self.builder.scalers.items()}
        reloaded = DataBuilder(ROOT, self.config, frozen_scalers=all_saved)
        day = pd.Timestamp("2025-01-01")
        altered = [Record(day, day, day, 999999., "new")]
        reloaded.aligned_group(key, altered, [day], "C")
        self.assertEqual(reloaded.scalers[key].as_dict(), self.builder.scalers[key].as_dict())


if __name__ == "__main__":
    unittest.main(verbosity=2)
