"""直接运行：载入最近一次训练的主干、本地头和冻结变换，仅做新预测。"""
from pathlib import Path
from datetime import datetime
import json
import torch
import pandas as pd
from src.data import DataBuilder, dump_json
from src.model import ForecastModel, collate
from src.train import schema, restore_client, disable_untrained, distribution_record, apply_calibration


def main():
    root = Path(__file__).resolve().parent
    marker = root/"results/LATEST_RUN.txt"
    if not marker.exists():
        raise FileNotFoundError("尚无已训练检查点，请先运行run_project.py。")
    stored = Path(marker.read_text(encoding="utf-8"))
    if not stored.exists():
        # 整个项目搬到另一台电脑后，从当前 results 查找完整训练目录。
        candidates = sorted(p for p in (root/"results").iterdir() if p.is_dir() and (p/"server/shared.pt").exists())
        if not candidates:
            raise FileNotFoundError("未找到完整检查点，请先运行run_project.py。")
        stored = candidates[-1]
    config = json.loads((stored/"config_used.json").read_text(encoding="utf-8"))
    torch.set_num_threads(config["cpu_threads"])
    if config["device"].startswith("cuda") and not torch.cuda.is_available():
        config["device"] = "cpu"
    device = torch.device(config["device"])
    frozen, target_states = {}, {}
    for client_dir in (stored/"clients").iterdir():
        frozen.update(json.loads((client_dir/"frozen_scalers.json").read_text(encoding="utf-8")))
        target_states.update({x["task"]: x for x in json.loads((client_dir/"task_metadata.json").read_text(encoding="utf-8"))})
    builder = DataBuilder(root, config, frozen, target_states)
    tasks, _ = builder.prepare()
    summary = json.loads((stored/"metrics.json").read_text(encoding="utf-8"))
    calibration = json.loads((stored/"interval_calibration.json").read_text(encoding="utf-8"))
    trained_blocks = set(summary["trained_blocks"]); trained_tasks = set(summary["trained_tasks"])
    initial = ForecastModel(tasks, builder.graph_input.shape[-1], config)
    manifest = schema(initial, config)
    rows = []
    for client in sorted({t.client for t in tasks}):
        model = ForecastModel(tasks, builder.graph_input.shape[-1], config).to(device)
        restore_client(model, stored/"server/shared.pt", stored/"clients"/client/"local_heads.pt", manifest, device)
        model.eval()
        for task in tasks:
            if task.client != client or task.task_id not in trained_tasks:
                continue
            origin = task.labels.end.max()
            sample = builder.inference_sample(task, origin)
            if sample is None:
                continue
            batch = collate([sample], device); disable_untrained(batch, trained_blocks)
            intervals = [(0, 7)] if task.frequency == "weekly" else [(i, i+1) for i in range(7)]
            with torch.no_grad():
                result = model(batch)
                for begin, finish in intervals:
                    label = {"begin": begin, "finish": finish, "Y": None, "n": None,
                             "start": str((origin+pd.Timedelta(days=begin+1)).date()),
                             "end": str((origin+pd.Timedelta(days=finish)).date())}
                    row = distribution_record(model, result, 0, sample, label, task)
                    row["data_status"] = "saved_model_engineering_forecast"
                    rows.append(row)
    apply_calibration(rows, calibration)
    output = stored/("predict_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f"));output.mkdir()
    dump_json(output/"forecasts.json", rows)
    dump_json(output/"data_audit.json", builder.audit)
    pd.DataFrame(rows).to_csv(output/"forecasts.csv", index=False, encoding="utf-8-sig")
    print("已载入成套模型与冻结变换，无重新训练。输出："+str(output), flush=True)
    return output


if __name__ == "__main__":
    main()
