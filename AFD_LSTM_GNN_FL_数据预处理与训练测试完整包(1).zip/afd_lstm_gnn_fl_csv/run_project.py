"""在 PyCharm 打开本目录，直接右键运行本文件；不需要命令行参数。"""
from pathlib import Path
from datetime import datetime
import json
import traceback
import random
import sys


def main():
    root = Path(__file__).resolve().parent
    output = root/"results"/datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    output.mkdir(parents=True, exist_ok=True)
    print("AFD + LSTM + GNN + FL：开始读取配置与数据。", flush=True)
    try:
        import numpy as np
        import torch
        from src.data import dump_json
        from src.prepared_csv import load_prepared, export_prepared
        from src.model import ForecastModel
        from src.train import fit_federated
        from src.plots import create_diagnostics
        config = json.loads((root/"config.json").read_text(encoding="utf-8"))
        if config["horizon_days"] != 7 or config["afd_components"] != 3:
            raise ValueError("当前原生周接口要求 H=7、M=3；L 可以修改为28/56/84。")
        if config["history_days"] < 7 or config["rounds"] < 1 or config["local_epochs"] < 1:
            raise ValueError("历史窗至少7天，训练轮次和本地epoch必须为正。")
        if not 0 <= config["baseline_loss_weight"] <= 1 or not 0 <= config["modality_dropout"] < 1:
            raise ValueError("缺省路径权重/遮蔽概率超出范围。")
        if (config["geo_distance_km"] <= 0 or config["decay_per_period"] < 0
                or config["max_train_windows_per_task"] < 0
                or any(v <= 0 for v in config["normal_period_days"].values())
                or any(v < 0 for v in config["assumed_release_delay_days"].values())):
            raise ValueError("距离尺度/更新周期必须为正；衰减、发布延迟、训练窗口上限不得为负。")
        random.seed(config["seed"]); np.random.seed(config["seed"]); torch.manual_seed(config["seed"])
        torch.set_num_threads(config["cpu_threads"])
        if config["device"].startswith("cuda") and not torch.cuda.is_available():
            raise ValueError("配置要求CUDA，但当前PyTorch/设备不可用；请在config.json改为cpu。")
        device = torch.device(config["device"])
        dump_json(output/"config_used.json", config)
        dump_json(output/"runtime_versions.json", {"python": sys.version, "numpy": np.__version__, "torch": torch.__version__})
        prepared = root/config.get("prepared_data_dir", "data/processed")
        if not (prepared/"manifest.json").exists():
            print("未找到预处理CSV，先生成并验证训练/测试数据。", flush=True)
            export_prepared(root, config)
        tasks, datasets, builder = load_prepared(prepared, config)
        dump_json(output/"prepared_input.json", {"directory": str(prepared),
            "files": builder.manifest["files"], "statistics": builder.manifest["statistics"]})
        print("本次训练及评价从train.csv/test.csv读取，不重新拟合预处理参数。", flush=True)
        dump_json(output/"data_audit.json", builder.audit)
        print(f"建立 {len(tasks)} 个任务，{len(set(t.client for t in tasks))} 个客户端。", flush=True)
        print("真实窗口数：", {k: len(v) for k, v in datasets.items()}, flush=True)
        for warning in builder.audit["warnings"]:
            print("数据说明："+warning, flush=True)
        if not datasets["train"]:
            raise ValueError("训练段没有有效窗口；请检查任务定义、时间切分或历史长度。")
        model = ForecastModel(tasks, builder.graph_input.shape[-1], config).to(device)
        dump_json(output/"parameter_mapping.json", {name: list(p.shape) for name, p in model.named_parameters()})
        models, summary, test_rows, forecasts = fit_federated(model, datasets, tasks, builder, config, output, device)
        if config["output_graphs"]:
            history = json.loads((output/"federated_history.json").read_text(encoding="utf-8"))
            create_diagnostics(builder, datasets, config, output, test_rows, history)
        (root/"results/LATEST_RUN.txt").write_text(str(output), encoding="utf-8")
        print("运行完成。输出目录："+str(output), flush=True)
        print("固定CSV训练/测试完成；新增原始数据的未来预测可运行predict_saved.py。", flush=True)
        print("默认3轮用于代码试跑；不代表模型已收敛或课题峰值指标已达标。", flush=True)
        return output
    except ModuleNotFoundError as exc:
        message = f"缺少依赖 {exc.name}。请在PyCharm所选解释器中安装requirements.txt列出的包。"
        (output/"error.log").write_text(message+"\n"+traceback.format_exc(), encoding="utf-8")
        print(message, flush=True); raise
    except Exception:
        (output/"error.log").write_text(traceback.format_exc(), encoding="utf-8")
        print("运行失败，完整诊断已保存到："+str(output/"error.log"), flush=True); raise


if __name__ == "__main__":
    main()
