"""PyCharm直接运行：清洗、对齐、分解后生成train.csv/test.csv，不训练模型。"""
from pathlib import Path
import json
from src.prepared_csv import export_prepared


def main():
    root = Path(__file__).resolve().parent
    config = json.loads((root/"config.json").read_text(encoding="utf-8"))
    destination, manifest = export_prepared(root, config)
    print("主数据文件：", destination/"train.csv", destination/"test.csv", flush=True)
    print("train.csv中的split=train用于训练，split=validation用于调优；test.csv只含测试。", flush=True)
    return destination, manifest


if __name__ == "__main__":
    main()
